package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

/**
 * Custom cover design for any document on the bookshelf.
 */
enum class CoverMotif(val displayName: String, val symbol: String) {
    BOOK("Open Codex", "📖"),
    OWL("Wise Owl", "🦉"),
    QUILL("Author Quill", "✒️"),
    CONSTELLATION("Orion Stars", "✨"),
    CROWN("Royal Crest", "👑"),
    COMPASS("Navigator Compass", "🧭"),
    TREE("Tree of Knowledge", "🌳"),
    SCROLL("Ancient Scroll", "📜")
}

enum class FoilColor(val displayName: String, val color: Color, val hex: String) {
    GOLD("Gilded Gold", Color(0xFFE2B755), "#E2B755"),
    SILVER("Moonlit Silver", Color(0xFFD4DAE2), "#D4DAE2"),
    BRONZE("Antique Bronze", Color(0xFFC7824E), "#C7824E"),
    ROSE_GOLD("Rose Gold", Color(0xFFE89DA8), "#E89DA8")
}

data class BookCoverConfig(
    val coverColorHex: String = "#101012", // Default deep obsidian black
    val motif: CoverMotif = CoverMotif.BOOK,
    val foilColor: FoilColor = FoilColor.GOLD,
    val customTitle: String? = null,
    val customSubtitle: String? = null,
    val customAuthor: String? = null,
    val customImageUri: String? = null
)

/**
 * Information about a connected Google Doc source.
 */
data class DocSource(
    val id: String,
    val rawUrl: String,
    val title: String,
    val lastSyncedTime: Long = System.currentTimeMillis(),
    val isSample: Boolean = false,
    val bookmarkPages: Set<Int> = emptySet(),
    val lastReadPageIndex: Int = 0,
    val readingProgressPercent: Float = 0f,
    val coverConfig: BookCoverConfig = BookCoverConfig(),
    val cachedContentHtml: String? = null,
    val isOfflineCached: Boolean = false
)

/**
 * Structural semantic elements that form the book content.
 */
sealed class BookElement {
    data class ChapterTitle(
        val title: String,
        val subtitle: String? = null,
        val chapterNumber: Int? = null
    ) : BookElement()

    data class Heading(
        val text: String,
        val level: Int = 1
    ) : BookElement()

    data class Paragraph(
        val text: String,
        val isFirstOfChapter: Boolean = false
    ) : BookElement()

    data class Blockquote(
        val quote: String,
        val attribution: String? = null
    ) : BookElement()

    data class BulletList(
        val items: List<String>
    ) : BookElement()

    object Divider : BookElement()
}

/**
 * A parsed book document ready for layout and pagination.
 */
data class BookContent(
    val docId: String,
    val title: String,
    val author: String? = null,
    val elements: List<BookElement> = emptyList(),
    val rawText: String = "",
    val tableOfContents: List<TocEntry> = emptyList(),
    val fetchedAt: Long = System.currentTimeMillis()
)

data class TocEntry(
    val title: String,
    val elementIndex: Int,
    val level: Int = 1,
    var pageNumber: Int = 1
)

/**
 * A single formatted page of the book.
 */
data class BookPage(
    val pageNumber: Int,
    val totalPages: Int,
    val runningHeader: String,
    val elements: List<BookElement>,
    val isCover: Boolean = false,
    val isChapterStart: Boolean = false
)

/**
 * A spread can contain one page (portrait/folded mode) or two pages (open Fold 8 mode).
 */
data class BookSpread(
    val spreadIndex: Int,
    val leftPage: BookPage,
    val rightPage: BookPage? = null,
    val isDualPage: Boolean = false
)

/**
 * Distinctive Paper Tones for physical book feel.
 */
enum class PaperTheme(
    val displayName: String,
    val backgroundColor: Color,
    val textColor: Color,
    val secondaryTextColor: Color,
    val borderColor: Color,
    val spineShadowColor: Color,
    val accentColor: Color,
    val isDark: Boolean = false
) {
    CLASSIC_CREAM(
        displayName = "Classic Cream",
        backgroundColor = PaperCream,
        textColor = InkEspresso,
        secondaryTextColor = InkSecondary,
        borderColor = PaperCreamBorder,
        spineShadowColor = Color(0x382A231D),
        accentColor = BookGoldDark,
        isDark = false
    ),
    VINTAGE_PARCHMENT(
        displayName = "Vintage Parchment",
        backgroundColor = ParchmentAmber,
        textColor = InkParchment,
        secondaryTextColor = Color(0xFF6B583F),
        borderColor = ParchmentBorder,
        spineShadowColor = Color(0x45382B1C),
        accentColor = Color(0xFF9E651D),
        isDark = false
    ),
    LINEN_WHITE(
        displayName = "Linen White",
        backgroundColor = LinenWhite,
        textColor = InkSlate,
        secondaryTextColor = Color(0xFF5A635E),
        borderColor = LinenBorder,
        spineShadowColor = Color(0x28000000),
        accentColor = BookNavy,
        isDark = false
    ),
    MIDNIGHT_LEATHER(
        displayName = "Pure Black AMOLED",
        backgroundColor = PureBlack,
        textColor = InkNight,
        secondaryTextColor = InkNightMuted,
        borderColor = PureBlackBorder,
        spineShadowColor = Color(0x99000000),
        accentColor = BookGoldLight,
        isDark = true
    ),
    E_INK(
        displayName = "E-Ink Paper",
        backgroundColor = EInkGray,
        textColor = InkBlack,
        secondaryTextColor = Color(0xFF444444),
        borderColor = Color(0xFFD0D0D0),
        spineShadowColor = Color(0x33000000),
        accentColor = InkBlack,
        isDark = false
    )
}

enum class FontChoice(val displayName: String) {
    PLAYFAIR_LORA("Literary Serif (Playfair + Lora)"),
    SYSTEM_SERIF("Classic Serif"),
    SYSTEM_SANS("Modern Sans"),
    MONOSPACE("Writer Monospace")
}

enum class FoldDisplayMode(val displayName: String) {
    AUTO_FOLD_DETECT("Auto (Dual on Open Fold)"),
    FORCE_DUAL_PAGE("Two Pages (Book Spread)"),
    FORCE_SINGLE_PAGE("Single Page")
}

enum class MarginSize(val displayName: String, val paddingDp: Int) {
    COMPACT("Compact", 16),
    COMFORTABLE("Comfortable", 28),
    GENEROUS("Wide Margins", 40)
}

enum class PageAnimationType(val displayName: String, val description: String) {
    PAGE_CURL("Page Curl", "Finger-tracked left/right page turning"),
    INSTANT("Instant", "Change pages immediately without an animation")
}

enum class PageSoundType(val displayName: String, val description: String) {
    NONE("None (Silent)", "Completely silent page turning"),
    MAGAZINE_GLOSS("Magazine Gloss", "Crisp, smooth coated paper slide like a glossy magazine"),
    NEWSPAPER_RUSTLE("Newspaper Broadsheet", "Fibrous, textured crinkle like turning a broadsheet newspaper"),
    HEAVY_PARCHMENT("Heavy Parchment", "Deep, warm cotton paper drag of a hardcover volume"),
    PAPERBACK_FLICK("Paperback Leaf Flick", "Snappy corner flick and quick leaf release")
}

data class SearchMatch(
    val pageNumber: Int,
    val snippet: String,
    val matchIndex: Int
)

data class SearchState(
    val query: String = "",
    val matches: List<SearchMatch> = emptyList(),
    val currentMatchIndex: Int = -1,
    val isActive: Boolean = false
)

enum class UiThemeMode(val displayName: String, val subtitle: String, val icon: String) {
    LIQUID_GLASS_DAY("Day Mode", "Bright high-contrast reading with dark legible text", "☀️"),
    AMOLED_NIGHT("AMOLED Pure Black (Night)", "True pitch black for zero power OLED night reading", "🌙")
}

data class ReaderPreferences(
    val paperTheme: PaperTheme = PaperTheme.LINEN_WHITE,
    val uiThemeMode: UiThemeMode = UiThemeMode.AMOLED_NIGHT,
    val fontChoice: FontChoice = FontChoice.PLAYFAIR_LORA,
    val fontSizeSp: Int = 16,
    val lineSpacingMultiplier: Float = 1.45f,
    val dropCapsEnabled: Boolean = true,
    val foldDisplayMode: FoldDisplayMode = FoldDisplayMode.AUTO_FOLD_DETECT,
    val marginSize: MarginSize = MarginSize.COMFORTABLE,
    val autoSyncIntervalSeconds: Int = 30, // Seconds between checks when auto-refresh is enabled
    val autoRefreshEnabled: Boolean = false, // Instant toggle button on reader
    val soundEnabled: Boolean = true, // Page turn sound effect
    val pageAnimationType: PageAnimationType = PageAnimationType.PAGE_CURL,
    val pageSoundType: PageSoundType = PageSoundType.MAGAZINE_GLOSS,
    val offlineOnlyMode: Boolean = false // Forced offline mode
)

sealed class SyncStatus {
    object Idle : SyncStatus()
    object Syncing : SyncStatus()
    data class Success(val lastSyncedTime: Long = System.currentTimeMillis()) : SyncStatus()
    data class Offline(val lastSyncedTime: Long = System.currentTimeMillis()) : SyncStatus()
    data class Error(val message: String, val time: Long = System.currentTimeMillis()) : SyncStatus()
}
