package com.example.ui

import androidx.compose.foundation.background
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import android.content.Intent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BookCoverConfig
import com.example.model.CoverMotif
import com.example.model.FoilColor
import com.example.ui.theme.PlayfairFontFamily

val COVER_COLOR_PALETTES = listOf(
    Pair("Obsidian", "#101012"),
    Pair("Onyx", "#1E1E22"),
    Pair("Navy", "#162238"),
    Pair("Emerald", "#142F22"),
    Pair("Burgundy", "#3D1A24"),
    Pair("Plum", "#36193E"),
    Pair("Charcoal", "#2C2C30")
)

/**
 * Renders a physical 3D hardcover book with foil stamping and spine crease.
 */
@Composable
fun BookCoverView(
    coverConfig: BookCoverConfig,
    defaultTitle: String,
    modifier: Modifier = Modifier,
    width: Dp = 140.dp,
    height: Dp = 200.dp,
    readingProgress: Float = 0f
) {
    val bgColor = try {
        Color(android.graphics.Color.parseColor(coverConfig.coverColorHex))
    } catch (e: Exception) {
        Color(0xFF3D1A24)
    }

    val foilColor = coverConfig.foilColor.color
    val title = coverConfig.customTitle?.takeIf { it.isNotBlank() } ?: defaultTitle
    val author = coverConfig.customAuthor ?: "Google Docs"

    Card(
        shape = RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp, topStart = 2.dp, bottomStart = 2.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = modifier
            .width(width)
            .height(height)
            .shadow(6.dp, RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.45f), // Spine shadow
                            Color.Black.copy(alpha = 0.15f),
                            bgColor,
                            bgColor,
                            Color.White.copy(alpha = 0.08f)  // Outer page light sheen
                        )
                    )
                )
                .drawBehind {
                    // Spine fold line
                    drawLine(
                        color = Color.Black.copy(alpha = 0.35f),
                        start = Offset(12.dp.toPx(), 0f),
                        end = Offset(12.dp.toPx(), size.height),
                        strokeWidth = 2.dp.toPx()
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.12f),
                        start = Offset(14.dp.toPx(), 0f),
                        end = Offset(14.dp.toPx(), size.height),
                        strokeWidth = 1.dp.toPx()
                    )
                }
                .padding(start = 16.dp, end = 10.dp, top = 12.dp, bottom = 12.dp)
        ) {
            // Optional user-supplied cover image (kept on device).
            coverConfig.customImageUri?.let { imageUri ->
                AsyncImage(
                    model = imageUri,
                    contentDescription = "Book cover",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            // Ornamental border in foil
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, foilColor.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                    .padding(6.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top Motif Icon
                    Text(
                        text = coverConfig.motif.symbol,
                        fontSize = (width.value * 0.18f).sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    // Title
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        Text(
                            text = title,
                            fontFamily = PlayfairFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = (width.value * 0.095f).coerceIn(11f, 16f).sp,
                            lineHeight = (width.value * 0.12f).coerceIn(14f, 20f).sp,
                            color = foilColor,
                            textAlign = TextAlign.Center,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .width(28.dp)
                                .height(1.dp)
                                .background(foilColor.copy(alpha = 0.7f))
                        )
                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = author,
                            fontFamily = PlayfairFontFamily,
                            fontStyle = FontStyle.Italic,
                            fontSize = (width.value * 0.07f).coerceIn(9f, 12f).sp,
                            color = foilColor.copy(alpha = 0.85f),
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Reading progress indicator on cover bottom
                    if (readingProgress > 0f) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${(readingProgress * 100).toInt()}% READ",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = foilColor.copy(alpha = 0.9f),
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.9f)
                                    .height(2.dp)
                                    .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(1.dp))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(readingProgress.coerceIn(0f, 1f))
                                        .fillMaxHeight()
                                        .background(foilColor, RoundedCornerShape(1.dp))
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "❦",
                            fontSize = 11.sp,
                            color = foilColor.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Dialog to design a custom book cover.
 */
@Composable
fun CustomCoverEditorDialog(
    initialConfig: BookCoverConfig,
    documentTitle: String,
    onSave: (BookCoverConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedColorHex by remember { mutableStateOf(initialConfig.coverColorHex) }
    var selectedMotif by remember { mutableStateOf(initialConfig.motif) }
    var selectedFoil by remember { mutableStateOf(initialConfig.foilColor) }
    var customTitle by remember { mutableStateOf(initialConfig.customTitle ?: documentTitle) }
    var customAuthor by remember { mutableStateOf(initialConfig.customAuthor ?: "Author") }
    var customImageUri by remember { mutableStateOf(initialConfig.customImageUri) }
    val context = LocalContext.current
    val chooseCoverImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { /* provider may not offer persistable grants */ }
            customImageUri = it.toString()
        }
    }

    val currentPreviewConfig = BookCoverConfig(
        coverColorHex = selectedColorHex,
        motif = selectedMotif,
        foilColor = selectedFoil,
        customTitle = customTitle,
        customAuthor = customAuthor,
        customImageUri = customImageUri
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Design Custom Book Cover", style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Live interactive 3D cover preview
                BookCoverView(
                    coverConfig = currentPreviewConfig,
                    defaultTitle = documentTitle,
                    width = 130.dp,
                    height = 180.dp,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(onClick = { chooseCoverImage.launch(arrayOf("image/*")) }) {
                    Text(if (customImageUri == null) "Choose cover photo" else "Change cover photo")
                }
                if (customImageUri != null) {
                    TextButton(onClick = { customImageUri = null }) { Text("Remove cover photo") }
                }
                // Title Input
                OutlinedTextField(
                    value = customTitle,
                    onValueChange = { customTitle = it },
                    label = { Text("Book Title on Cover") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Author Input
                OutlinedTextField(
                    value = customAuthor,
                    onValueChange = { customAuthor = it },
                    label = { Text("Author / Note") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Cover Leather Color
                Text(
                    text = "COVER LEATHER COLOR",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for ((name, hex) in COVER_COLOR_PALETTES) {
                        val color = Color(android.graphics.Color.parseColor(hex))
                        val isSelected = selectedColorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.5f),
                                    shape = CircleShape
                                )
                                .clickable { selectedColorHex = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Motif
                Text(
                    text = "EMBOSSED MOTIF",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (motif in CoverMotif.values().take(4)) {
                        FilterChip(
                            selected = selectedMotif == motif,
                            onClick = { selectedMotif = motif },
                            label = { Text(motif.symbol + " " + motif.displayName.split(" ").first()) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (motif in CoverMotif.values().drop(4).take(4)) {
                        FilterChip(
                            selected = selectedMotif == motif,
                            onClick = { selectedMotif = motif },
                            label = { Text(motif.symbol + " " + motif.displayName.split(" ").first()) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Foil Stamping
                Text(
                    text = "FOIL STAMPING",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (foil in FoilColor.values()) {
                        FilterChip(
                            selected = selectedFoil == foil,
                            onClick = { selectedFoil = foil },
                            label = { Text(foil.displayName.split(" ").first()) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(currentPreviewConfig) }) {
                Text("Apply Custom Cover")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
