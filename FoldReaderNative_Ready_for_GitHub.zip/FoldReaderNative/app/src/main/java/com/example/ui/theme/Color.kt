package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Literary Palette
val BookGold = Color(0xFFC59B27)
val BookGoldLight = Color(0xFFE2B755)
val BookGoldDark = Color(0xFF8C6D13)

val BookNavy = Color(0xFF1B263B)
val BookNavyDark = Color(0xFF0D1B2A)
val BookNavyLight = Color(0xFF415A77)

val PaperCream = Color(0xFFFBF7EE)
val PaperCreamBorder = Color(0xFFE8E0D0)
val InkEspresso = Color(0xFF2A231D)
val InkSecondary = Color(0xFF6B5F54)

val ParchmentAmber = Color(0xFFF4EAD4)
val ParchmentBorder = Color(0xFFDECFAF)
val InkParchment = Color(0xFF382B1C)

val LinenWhite = Color(0xFFFAFAFA)
val LinenBorder = Color(0xFFE5E5E5)
val InkSlate = Color(0xFF1F2421)

// Pure AMOLED Black Palette (No brown tones)
val PureBlack = Color(0xFF000000)
val PureBlackSurface = Color(0xFF000000)
val PureBlackCard = Color(0xFF101010)
val PureBlackBorder = Color(0xFF202020)
val PureBlackGutter = Color(0xFF080808)

val LeatherDark = Color(0xFF000000) // Pure black
val LeatherBorder = Color(0xFF1F1F1F)
val InkNight = Color(0xFFF0F0F0)
val InkNightMuted = Color(0xFFA0A0A0)

val EInkGray = Color(0xFFECECEC)
val InkBlack = Color(0xFF111111)

val LiveSyncGreen = Color(0xFF10B981)
val LiveSyncGreenGlow = Color(0x3310B981)
