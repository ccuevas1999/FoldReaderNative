package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.parser.GoogleDocsService
import com.example.reader.PaginationEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

data class DocuBookUiState(
    val activeDocSource: DocSource? = null,
    val activeBookContent: BookContent? = null,
    val pages: List<BookPage> = emptyList(),
    val spreads: List<BookSpread> = emptyList(),
    val currentSpreadIndex: Int = 0,
    val isDualPageActive: Boolean = false,
    val windowWidthDp: Float = 400f,
    val windowHeightDp: Float = 800f,
    val syncStatus: SyncStatus = SyncStatus.Idle,
    val recentDocs: List<DocSource> = emptyList(),
    val sampleDocs: List<BookContent> = emptyList(),
    val preferences: ReaderPreferences = ReaderPreferences(),
    val searchState: SearchState = SearchState(),
    val isSearchOpen: Boolean = false,
    val isControlsVisible: Boolean = true,
    val isSettingsOpen: Boolean = false,
    val isTocOpen: Boolean = false,
    val isCoverEditorOpen: Boolean = false,
    val coverEditorTargetDoc: DocSource? = null,
    val isInLiveEditorMode: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class DocuBookViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("docubook_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(
        DocuBookUiState(
            sampleDocs = GoogleDocsService.getSampleBooks(),
            recentDocs = loadSavedRecentDocs()
        )
    )
    val uiState: StateFlow<DocuBookUiState> = _uiState.asStateFlow()

    private var autoSyncJob: Job? = null
    private var paginationJob: Job? = null

    private fun cacheFile(docId: String): File {
        val safeId = docId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        return File(getApplication<Application>().filesDir, "doc_$safeId.html")
    }

    private fun saveDocCache(docId: String, html: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { cacheFile(docId).writeText(html) }
        }
    }

    private fun readDocCache(docId: String): String? =
        runCatching { cacheFile(docId).takeIf { it.isFile }?.readText() }.getOrNull()


    init {
        // Automatically open the first recent or sample book
        val recents = _uiState.value.recentDocs
        if (recents.isNotEmpty()) {
            loadDocFromSource(recents.first(), restoreProgress = true)
        } else {
            val samples = GoogleDocsService.getSampleBooks()
            if (samples.isNotEmpty()) {
                openSampleBook(samples.first())
            }
        }
    }

    /**
     * Determines whether dual-page mode should be enabled based on
     * the foldable screen width (Fold 8 unfolded >= 600dp) or user preference.
     */
    fun updateWindowDimensions(widthDp: Float, heightDp: Float) {
        val prefsMode = _uiState.value.preferences.foldDisplayMode
        val shouldBeDual = when (prefsMode) {
            FoldDisplayMode.AUTO_FOLD_DETECT -> widthDp >= 600f && widthDp > heightDp
            FoldDisplayMode.FORCE_DUAL_PAGE -> widthDp > heightDp
            FoldDisplayMode.FORCE_SINGLE_PAGE -> false
        }

        if (shouldBeDual != _uiState.value.isDualPageActive || widthDp != _uiState.value.windowWidthDp || heightDp != _uiState.value.windowHeightDp) {
            _uiState.update { it.copy(windowWidthDp = widthDp, windowHeightDp = heightDp, isDualPageActive = shouldBeDual) }
            rePaginateCurrentContent()
        }
    }

    /**
     * Loads a live Google Docs URL.
     */
    fun loadDocFromUrl(url: String, customCover: BookCoverConfig? = null) {
        val docId = GoogleDocsService.extractDocId(url)
        if (docId == null) {
            _uiState.update {
                it.copy(
                    errorMessage = "Invalid Google Docs link. Please paste a link like: https://docs.google.com/document/d/..."
                )
            }
            return
        }

        // Check if we have an existing source for this ID
        val existing = _uiState.value.recentDocs.find { it.id == docId }
        val cover = customCover ?: existing?.coverConfig ?: BookCoverConfig()

        if (_uiState.value.preferences.offlineOnlyMode && existing != null && cacheFile(docId).isFile) {
            // Offline Mode explicitly active
            val cachedContent = GoogleDocsService.parseHtmlContent(docId, readDocCache(docId).orEmpty())
            val source = existing.copy(isOfflineCached = true)
            _uiState.update {
                it.copy(
                    activeDocSource = source,
                    activeBookContent = cachedContent,
                    isLoading = false,
                    syncStatus = SyncStatus.Offline(source.lastSyncedTime),
                    errorMessage = null
                )
            }
            rePaginateCurrentContent()
            return
        }

        _uiState.update { it.copy(isLoading = true, errorMessage = null, syncStatus = SyncStatus.Syncing) }

        viewModelScope.launch {
            val result = GoogleDocsService.fetchDocument(docId)
            result.onSuccess { content ->
                val source = (existing ?: DocSource(
                    id = docId,
                    rawUrl = url,
                    title = content.title
                )).copy(
                    title = content.title,
                    lastSyncedTime = System.currentTimeMillis(),
                    cachedContentHtml = content.rawText,
                    isOfflineCached = true,
                    coverConfig = cover
                )
                saveDocCache(docId, content.rawText)
                saveRecentDoc(source)

                _uiState.update {
                    it.copy(
                        activeDocSource = source,
                        activeBookContent = content,
                        isLoading = false,
                        syncStatus = SyncStatus.Success(source.lastSyncedTime),
                        errorMessage = null,
                        currentSpreadIndex = existing?.lastReadPageIndex ?: 0,
                        pages = emptyList(),
                        spreads = emptyList()
                    )
                }
                rePaginateCurrentContent()
                restartAutoSyncTimer()
            }.onFailure { error ->
                // Check if we have cached copy to read in Offline Mode!
                if (existing != null && cacheFile(docId).isFile) {
                    val cachedContent = GoogleDocsService.parseHtmlContent(docId, readDocCache(docId).orEmpty())
                    _uiState.update {
                        it.copy(
                            activeDocSource = existing.copy(isOfflineCached = true),
                            activeBookContent = cachedContent,
                            isLoading = false,
                            syncStatus = SyncStatus.Offline(existing.lastSyncedTime),
                            errorMessage = "Network unavailable. Reading offline cached copy."
                        )
                    }
                    rePaginateCurrentContent()
                } else {
                    // Fallback guidance
                    val fallbackSource = DocSource(
                        id = docId,
                        rawUrl = url,
                        title = "Google Document",
                        coverConfig = cover
                    )
                    val fallbackContent = GoogleDocsService.parsePlainTextContent(
                        docId,
                        "Document: Google Doc ($docId)\n\n" +
                                "This document requires authentication or has restricted export permissions.\n\n" +
                                "Tap the Live Docs Editor button in the top bar to view, authenticate, and edit it directly within Google Docs, or make sure the sharing settings are set to 'Anyone with the link can view'."
                    )
                    _uiState.update {
                        it.copy(
                            activeDocSource = fallbackSource,
                            activeBookContent = fallbackContent,
                            isLoading = false,
                            syncStatus = SyncStatus.Error("Private doc or offline"),
                            errorMessage = error.message
                        )
                    }
                    rePaginateCurrentContent()
                }
            }
        }
    }

    fun loadDocFromSource(source: DocSource, restoreProgress: Boolean = false) {
        if (source.isSample) {
            val sample = _uiState.value.sampleDocs.find { it.docId == source.id }
            if (sample != null) {
                openSampleBook(sample)
                return
            }
        }

        // If offline mode or cached content is available, display immediately
        if (_uiState.value.preferences.offlineOnlyMode && cacheFile(source.id).isFile) {
            val content = GoogleDocsService.parseHtmlContent(source.id, readDocCache(source.id).orEmpty())
            _uiState.update {
                it.copy(
                    activeDocSource = source,
                    activeBookContent = content,
                    syncStatus = SyncStatus.Offline(source.lastSyncedTime),
                    currentSpreadIndex = if (restoreProgress) source.lastReadPageIndex else 0
                )
            }
            rePaginateCurrentContent()
            return
        }

        loadDocFromUrl(source.rawUrl, source.coverConfig)
    }

    fun openSampleBook(content: BookContent) {
        val existing = _uiState.value.recentDocs.find { it.id == content.docId }
        val source = DocSource(
            id = content.docId,
            rawUrl = "sample://${content.docId}",
            title = content.title,
            isSample = true,
            coverConfig = existing?.coverConfig ?: BookCoverConfig(
                customTitle = content.title,
                customAuthor = content.author ?: "Sample Manuscript"
            ),
            isOfflineCached = true
        )
        _uiState.update {
            it.copy(
                activeDocSource = source,
                activeBookContent = content,
                syncStatus = SyncStatus.Idle,
                currentSpreadIndex = 0,
                errorMessage = null
            )
        }
        rePaginateCurrentContent()
    }

    fun manualSync() {
        val source = _uiState.value.activeDocSource ?: return
        if (source.isSample) {
            _uiState.update { it.copy(syncStatus = SyncStatus.Success()) }
            return
        }

        if (_uiState.value.preferences.offlineOnlyMode) {
            _uiState.update { it.copy(syncStatus = SyncStatus.Offline(source.lastSyncedTime)) }
            return
        }

        _uiState.update { it.copy(syncStatus = SyncStatus.Syncing) }

        viewModelScope.launch {
            val result = GoogleDocsService.fetchDocument(source.id)
            result.onSuccess { newContent ->
                val prevContent = _uiState.value.activeBookContent
                val contentChanged = prevContent == null || prevContent.rawText != newContent.rawText

                val updatedSource = source.copy(
                    lastSyncedTime = System.currentTimeMillis(),
                    cachedContentHtml = newContent.rawText,
                    isOfflineCached = true
                )
                saveDocCache(source.id, newContent.rawText)
                saveRecentDoc(updatedSource)

                _uiState.update {
                    it.copy(
                        activeDocSource = updatedSource,
                        activeBookContent = newContent,
                        syncStatus = SyncStatus.Success()
                    )
                }

                if (contentChanged) {
                    rePaginateCurrentContent()
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(syncStatus = SyncStatus.Offline(source.lastSyncedTime))
                }
            }
        }
    }

    fun toggleAutoRefresh() {
        val current = _uiState.value.preferences.autoRefreshEnabled
        val newPrefs = _uiState.value.preferences.copy(autoRefreshEnabled = !current)
        updatePreferences(newPrefs)
    }

    fun toggleSound() {
        val current = _uiState.value.preferences.soundEnabled
        val newPrefs = _uiState.value.preferences.copy(soundEnabled = !current)
        updatePreferences(newPrefs)
    }

    fun toggleOfflineMode() {
        val current = _uiState.value.preferences.offlineOnlyMode
        val newPrefs = _uiState.value.preferences.copy(offlineOnlyMode = !current)
        updatePreferences(newPrefs)
    }

    private fun restartAutoSyncTimer() {
        autoSyncJob?.cancel()
        val prefs = _uiState.value.preferences
        val intervalSec = prefs.autoSyncIntervalSeconds
        val source = _uiState.value.activeDocSource

        if (!prefs.autoRefreshEnabled || prefs.offlineOnlyMode || intervalSec <= 0 || source == null || source.isSample) {
            return
        }

        autoSyncJob = viewModelScope.launch {
            while (isActive) {
                delay(intervalSec * 1000L)
                val currentSource = _uiState.value.activeDocSource ?: break
                if (currentSource.isSample || _uiState.value.preferences.offlineOnlyMode) break

                val result = GoogleDocsService.fetchDocument(currentSource.id)
                result.onSuccess { newContent ->
                    val prevContent = _uiState.value.activeBookContent
                    if (prevContent == null || prevContent.rawText != newContent.rawText) {
                        val updatedSource = currentSource.copy(
                            lastSyncedTime = System.currentTimeMillis(),
                            cachedContentHtml = newContent.rawText,
                            isOfflineCached = true
                        )
                        saveDocCache(currentSource.id, newContent.rawText)
                        saveRecentDoc(updatedSource)

                        _uiState.update {
                            it.copy(
                                activeDocSource = updatedSource,
                                activeBookContent = newContent,
                                syncStatus = SyncStatus.Success()
                            )
                        }
                        rePaginateCurrentContent()
                    }
                }
            }
        }
    }

    private fun rePaginateCurrentContent() {
        val content = _uiState.value.activeBookContent ?: return
        val chosenPrefs = _uiState.value.preferences
        val isDual = _uiState.value.isDualPageActive
        val previousIndex = _uiState.value.currentSpreadIndex
        val previousSpread = _uiState.value.spreads.getOrNull(previousIndex)
        val anchorPageNumber = previousSpread?.leftPage?.pageNumber ?: 1
        paginationJob?.cancel()
        paginationJob = viewModelScope.launch {
            val pages = withContext(Dispatchers.Default) {
                PaginationEngine.paginate(content, chosenPrefs, isDual)
            }
            val spreads = withContext(Dispatchers.Default) {
                PaginationEngine.createSpreads(pages, isDual)
            }
            // Check active book hasn't changed while the pages were being calculated.
            if (_uiState.value.activeBookContent !== content) return@launch
            val matched = spreads.indexOfFirst {
                it.leftPage.pageNumber == anchorPageNumber || it.rightPage?.pageNumber == anchorPageNumber
            }
            val currentState = _uiState.value
            val savedProgress = currentState.activeDocSource?.readingProgressPercent ?: 0f
            val byProgress = if (currentState.spreads.isEmpty() && savedProgress > 0f) {
                (savedProgress * spreads.size).toInt().coerceAtLeast(0)
            } else previousIndex
            val safeIndex = (if (currentState.spreads.isEmpty()) byProgress
                             else if (matched >= 0) matched else previousIndex)
                .coerceIn(0, (spreads.size - 1).coerceAtLeast(0))
            _uiState.update {
                it.copy(pages = pages, spreads = spreads, currentSpreadIndex = safeIndex)
            }
            updateReadingProgress(safeIndex, spreads.size)
        }
    }

    fun setSpreadIndex(index: Int) {
        val maxIndex = (_uiState.value.spreads.size - 1).coerceAtLeast(0)
        val clamped = index.coerceIn(0, maxIndex)
        _uiState.update { it.copy(currentSpreadIndex = clamped) }
        updateReadingProgress(clamped, _uiState.value.spreads.size)
    }

    private fun updateReadingProgress(spreadIndex: Int, totalSpreads: Int) {
        val source = _uiState.value.activeDocSource ?: return
        val progress = if (totalSpreads > 0) {
            ((spreadIndex + 1).toFloat() / totalSpreads.toFloat()).coerceIn(0f, 1f)
        } else 0f

        val updated = source.copy(
            lastReadPageIndex = spreadIndex,
            readingProgressPercent = progress
        )
        _uiState.update { it.copy(activeDocSource = updated) }
        saveRecentDoc(updated)
    }

    fun jumpToPage(pageNumber: Int) {
        val spreads = _uiState.value.spreads
        val targetSpreadIndex = spreads.indexOfFirst { spread ->
            spread.leftPage.pageNumber == pageNumber ||
                    (spread.rightPage != null && spread.rightPage.pageNumber == pageNumber)
        }
        if (targetSpreadIndex >= 0) {
            setSpreadIndex(targetSpreadIndex)
        }
    }

    fun toggleBookmark(pageNumber: Int) {
        val source = _uiState.value.activeDocSource ?: return
        val currentMarks = source.bookmarkPages.toMutableSet()
        if (currentMarks.contains(pageNumber)) {
            currentMarks.remove(pageNumber)
        } else {
            currentMarks.add(pageNumber)
        }
        val updatedSource = source.copy(bookmarkPages = currentMarks)
        _uiState.update { it.copy(activeDocSource = updatedSource) }
        saveRecentDoc(updatedSource)
    }

    fun isPageBookmarked(pageNumber: Int): Boolean {
        return _uiState.value.activeDocSource?.bookmarkPages?.contains(pageNumber) == true
    }

    fun updateBookCover(docId: String, newCover: BookCoverConfig) {
        val recents = _uiState.value.recentDocs.map {
            if (it.id == docId) it.copy(coverConfig = newCover) else it
        }
        _uiState.update {
            it.copy(
                recentDocs = recents,
                activeDocSource = if (it.activeDocSource?.id == docId) it.activeDocSource?.copy(coverConfig = newCover) else it.activeDocSource,
                isCoverEditorOpen = false,
                coverEditorTargetDoc = null
            )
        }
        recents.find { it.id == docId }?.let { saveRecentDoc(it) }
    }

    fun openCoverEditor(doc: DocSource) {
        _uiState.update { it.copy(isCoverEditorOpen = true, coverEditorTargetDoc = doc) }
    }

    fun closeCoverEditor() {
        _uiState.update { it.copy(isCoverEditorOpen = false, coverEditorTargetDoc = null) }
    }

    fun updatePreferences(newPrefs: ReaderPreferences) {
        _uiState.update { it.copy(preferences = newPrefs) }
        updateWindowDimensions(_uiState.value.windowWidthDp, _uiState.value.windowHeightDp)
        rePaginateCurrentContent()
        restartAutoSyncTimer()
    }

    fun setUiThemeMode(mode: UiThemeMode) {
        val adaptedPaper = if (mode == UiThemeMode.LIQUID_GLASS_DAY) {
            if (_uiState.value.preferences.paperTheme.isDark) PaperTheme.LINEN_WHITE else _uiState.value.preferences.paperTheme
        } else {
            PaperTheme.MIDNIGHT_LEATHER
        }
        val updated = _uiState.value.preferences.copy(
            uiThemeMode = mode,
            paperTheme = adaptedPaper
        )
        updatePreferences(updated)
    }

    fun cycleUiThemeMode() {
        val current = _uiState.value.preferences.uiThemeMode
        val next = if (current == UiThemeMode.LIQUID_GLASS_DAY) {
            UiThemeMode.AMOLED_NIGHT
        } else {
            UiThemeMode.LIQUID_GLASS_DAY
        }
        setUiThemeMode(next)
    }

    fun toggleControls() {
        _uiState.update { it.copy(isControlsVisible = !it.isControlsVisible) }
    }

    fun openSettings() {
        _uiState.update { it.copy(isSettingsOpen = true) }
    }

    fun closeSettings() {
        _uiState.update { it.copy(isSettingsOpen = false) }
    }

    fun openToc() {
        _uiState.update { it.copy(isTocOpen = true) }
    }

    fun closeToc() {
        _uiState.update { it.copy(isTocOpen = false) }
    }

    fun openSearch() {
        _uiState.update { it.copy(isSearchOpen = true) }
    }

    fun closeSearch() {
        _uiState.update { it.copy(isSearchOpen = false) }
    }

    fun performSearch(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            _uiState.update { it.copy(searchState = SearchState(query = "")) }
            return
        }

        val pages = _uiState.value.pages
        val matches = mutableListOf<SearchMatch>()
        var matchCounter = 0

        for (page in pages) {
            for (element in page.elements) {
                val elementText = when (element) {
                    is BookElement.Paragraph -> element.text
                    is BookElement.Heading -> element.text
                    is BookElement.ChapterTitle -> "${element.title} ${element.subtitle.orEmpty()}"
                    is BookElement.Blockquote -> element.quote
                    is BookElement.BulletList -> element.items.joinToString(" ")
                    BookElement.Divider -> ""
                }

                if (elementText.contains(trimmed, ignoreCase = true)) {
                    val lowerElem = elementText.lowercase()
                    val lowerQuery = trimmed.lowercase()
                    var idx = lowerElem.indexOf(lowerQuery)
                    while (idx >= 0) {
                        val start = (idx - 35).coerceAtLeast(0)
                        val end = (idx + trimmed.length + 35).coerceAtMost(elementText.length)
                        val prefix = if (start > 0) "…" else ""
                        val suffix = if (end < elementText.length) "…" else ""
                        val snippet = prefix + elementText.substring(start, end).replace("\n", " ") + suffix

                        matches.add(SearchMatch(pageNumber = page.pageNumber, snippet = snippet, matchIndex = matchCounter++))
                        idx = lowerElem.indexOf(lowerQuery, idx + lowerQuery.length)
                    }
                }
            }
        }

        _uiState.update {
            it.copy(
                searchState = SearchState(
                    query = query,
                    matches = matches,
                    currentMatchIndex = if (matches.isNotEmpty()) 0 else -1,
                    isActive = true
                )
            )
        }

        if (matches.isNotEmpty()) {
            jumpToPage(matches[0].pageNumber)
        }
    }

    fun selectSearchMatch(index: Int) {
        val matches = _uiState.value.searchState.matches
        if (index in matches.indices) {
            _uiState.update {
                it.copy(searchState = it.searchState.copy(currentMatchIndex = index))
            }
            jumpToPage(matches[index].pageNumber)
        }
    }

    fun nextSearchMatch() {
        val matches = _uiState.value.searchState.matches
        if (matches.isEmpty()) return
        val currentIndex = _uiState.value.searchState.currentMatchIndex
        val nextIdx = (currentIndex + 1) % matches.size
        selectSearchMatch(nextIdx)
    }

    fun prevSearchMatch() {
        val matches = _uiState.value.searchState.matches
        if (matches.isEmpty()) return
        val currentIndex = _uiState.value.searchState.currentMatchIndex
        val prevIdx = if (currentIndex <= 0) matches.size - 1 else currentIndex - 1
        selectSearchMatch(prevIdx)
    }

    fun openLiveEditor() {
        _uiState.update { it.copy(isInLiveEditorMode = true) }
    }

    fun closeLiveEditor() {
        _uiState.update { it.copy(isInLiveEditorMode = false) }
        manualSync()
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun removeBookFromShelf(docId: String) {
        val current = _uiState.value.recentDocs.filterNot { it.id == docId }
        _uiState.update { it.copy(recentDocs = current) }
        persistRecentDocsList(current)
    }

    private fun loadSavedRecentDocs(): List<DocSource> {
        val jsonStr = prefs.getString("saved_recent_docs", null) ?: return emptyList()
        val list = mutableListOf<DocSource>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val bookmarks = mutableSetOf<Int>()
                val bArray = obj.optJSONArray("bookmarks")
                if (bArray != null) {
                    for (b in 0 until bArray.length()) {
                        bookmarks.add(bArray.getInt(b))
                    }
                }

                val coverObj = obj.optJSONObject("cover")
                val cover = if (coverObj != null) {
                    BookCoverConfig(
                        coverColorHex = coverObj.optString("color", "#3D1A24"),
                        motif = CoverMotif.values().find { it.name == coverObj.optString("motif") } ?: CoverMotif.BOOK,
                        foilColor = FoilColor.values().find { it.name == coverObj.optString("foil") } ?: FoilColor.GOLD,
                        customTitle = coverObj.optString("title").takeIf { it.isNotBlank() },
                        customAuthor = coverObj.optString("author").takeIf { it.isNotBlank() },
                        customImageUri = coverObj.optString("image").takeIf { it.isNotBlank() }
                    )
                } else BookCoverConfig()

                list.add(
                    DocSource(
                        id = obj.getString("id"),
                        rawUrl = obj.getString("url"),
                        title = obj.getString("title"),
                        lastSyncedTime = obj.optLong("lastSyncedTime", System.currentTimeMillis()),
                        bookmarkPages = bookmarks,
                        lastReadPageIndex = obj.optInt("lastPage", 0),
                        readingProgressPercent = obj.optDouble("progress", 0.0).toFloat(),
                        coverConfig = cover,
                        cachedContentHtml = null,
                        isOfflineCached = cacheFile(obj.getString("id")).isFile
                    )
                )
            }
        } catch (e: Exception) {
            // ignore
        }
        return list
    }

    private fun saveRecentDoc(doc: DocSource) {
        if (doc.isSample) return
        val current = _uiState.value.recentDocs.toMutableList()
        current.removeAll { it.id == doc.id }
        current.add(0, doc)
        _uiState.update { it.copy(recentDocs = current) }
        persistRecentDocsList(current)
    }

    private fun persistRecentDocsList(list: List<DocSource>) {
        try {
            val array = JSONArray()
            for (item in list.take(20)) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("url", item.rawUrl)
                obj.put("title", item.title)
                obj.put("lastSyncedTime", item.lastSyncedTime)
                obj.put("lastPage", item.lastReadPageIndex)
                obj.put("progress", item.readingProgressPercent.toDouble())
                obj.put("isCached", item.isOfflineCached)

                val coverObj = JSONObject()
                coverObj.put("color", item.coverConfig.coverColorHex)
                coverObj.put("motif", item.coverConfig.motif.name)
                coverObj.put("foil", item.coverConfig.foilColor.name)
                coverObj.put("title", item.coverConfig.customTitle ?: "")
                coverObj.put("author", item.coverConfig.customAuthor ?: "")
                coverObj.put("image", item.coverConfig.customImageUri ?: "")
                obj.put("cover", coverObj)

                val bArray = JSONArray()
                item.bookmarkPages.forEach { bArray.put(it) }
                obj.put("bookmarks", bArray)
                array.put(obj)
            }
            prefs.edit().putString("saved_recent_docs", array.toString()).apply()
        } catch (e: Exception) {
            // ignore
        }
    }
}
