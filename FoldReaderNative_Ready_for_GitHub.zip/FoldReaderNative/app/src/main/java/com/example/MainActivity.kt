package com.example

import android.content.Intent
import android.app.Activity
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.compose.BackHandler
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.ui.BookShelfScreen
import com.example.ui.CustomCoverEditorDialog
import com.example.ui.ReaderScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.DocuBookViewModel

enum class AppScreen {
    BOOKSHELF,
    READER
}

class MainActivity : ComponentActivity() {

    private val viewModel: DocuBookViewModel by viewModels()
    private var openedFromShare = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIncomingIntent(intent)

        setContent {
            MyApplicationTheme {
                DocuBookApp(viewModel = viewModel, initiallyRead = openedFromShare)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val data = intent.data

        if (Intent.ACTION_VIEW == action && data != null) {
            openedFromShare = true
            viewModel.loadDocFromUrl(data.toString())
        } else if (Intent.ACTION_SEND == action && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                openedFromShare = true
                viewModel.loadDocFromUrl(sharedText)
            }
        }
    }
}

@Composable
fun DocuBookApp(viewModel: DocuBookViewModel, initiallyRead: Boolean = false) {
    val uiState by viewModel.uiState.collectAsState()
    var currentScreen by remember { mutableStateOf(if (initiallyRead) AppScreen.READER else AppScreen.BOOKSHELF) }

    // Native immersive reading. No AppCreator24 bar, no status/navigation bars on book pages.
    val activity = LocalContext.current as? Activity
    SideEffect {
        activity?.let { host ->
            val controller = WindowCompat.getInsetsController(host.window, host.window.decorView)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (currentScreen == AppScreen.READER) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        when (currentScreen) {
            AppScreen.BOOKSHELF -> {
                BookShelfScreen(
                    recentDocs = uiState.recentDocs,
                    sampleDocs = uiState.sampleDocs,
                    isLoading = uiState.isLoading,
                    isOfflineOnly = uiState.preferences.offlineOnlyMode,
                    errorMessage = uiState.errorMessage,
                    uiThemeMode = uiState.preferences.uiThemeMode,
                    onCycleUiThemeMode = { viewModel.cycleUiThemeMode() },
                    onOpenUrl = { url, coverConfig ->
                        viewModel.loadDocFromUrl(url, coverConfig)
                        currentScreen = AppScreen.READER
                    },
                    onOpenSample = { sample ->
                        viewModel.openSampleBook(sample)
                        currentScreen = AppScreen.READER
                    },
                    onOpenRecent = { recent ->
                        viewModel.loadDocFromSource(recent, restoreProgress = true)
                        currentScreen = AppScreen.READER
                    },
                    onEditCover = { doc ->
                        viewModel.openCoverEditor(doc)
                    },
                    onRemoveBook = { docId ->
                        viewModel.removeBookFromShelf(docId)
                    },
                    onToggleOfflineMode = {
                        viewModel.toggleOfflineMode()
                    },
                    onClearError = { viewModel.clearError() }
                )
            }
            AppScreen.READER -> {
                ReaderScreen(
                    viewModel = viewModel,
                    onNavigateBackToShelf = {
                        currentScreen = AppScreen.BOOKSHELF
                    }
                )
            }
        }

        // Custom Cover Editor Dialog
        if (uiState.isCoverEditorOpen && uiState.coverEditorTargetDoc != null) {
            val targetDoc = uiState.coverEditorTargetDoc!!
            CustomCoverEditorDialog(
                initialConfig = targetDoc.coverConfig,
                documentTitle = targetDoc.title,
                onSave = { newConfig ->
                    viewModel.updateBookCover(targetDoc.id, newConfig)
                },
                onDismiss = {
                    viewModel.closeCoverEditor()
                }
            )
        }
    }
}
