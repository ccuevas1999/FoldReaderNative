package com.example.parser

import com.example.model.BookContent
import com.example.model.BookElement
import com.example.model.TocEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object GoogleDocsService {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /**
     * Extracts Google Docs document ID from various URL styles or raw IDs.
     */
    fun extractDocId(input: String): String? {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return null

        // If user directly pasted an ID like 1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms
        val rawIdPattern = Pattern.compile("^[a-zA-Z0-9_-]{25,60}$")
        if (rawIdPattern.matcher(trimmed).matches()) {
            return trimmed
        }

        // Standard docs.google.com/document/d/{id}/...
        val standardPattern = Pattern.compile("docs\\.google\\.com/document/(?:u/\\d+/)?d/([a-zA-Z0-9_-]+)")
        val standardMatcher = standardPattern.matcher(trimmed)
        if (standardMatcher.find()) {
            return standardMatcher.group(1)
        }

        // Drive open?id={id}
        val drivePattern = Pattern.compile("[?&]id=([a-zA-Z0-9_-]+)")
        val driveMatcher = drivePattern.matcher(trimmed)
        if (driveMatcher.find()) {
            return driveMatcher.group(1)
        }

        // drive.google.com/file/d/{id}
        val filePattern = Pattern.compile("drive\\.google\\.com/file/d/([a-zA-Z0-9_-]+)")
        val fileMatcher = filePattern.matcher(trimmed)
        if (fileMatcher.find()) {
            return fileMatcher.group(1)
        }

        return null
    }

    /**
     * Constructs the web URL for viewing or editing.
     */
    fun getDocsWebUrl(docId: String): String {
        return "https://docs.google.com/document/d/$docId/edit"
    }

    /**
     * Fetches live document content from Google Docs export endpoint.
     */
    suspend fun fetchDocument(docId: String): Result<BookContent> = withContext(Dispatchers.IO) {
        // Try HTML export first for rich typography and formatting
        val htmlUrl = "https://docs.google.com/document/d/$docId/export?format=html"
        val request = Request.Builder()
            .url(htmlUrl)
            .header("User-Agent", "Mozilla/5.0 (Android; Mobile) DocuBook/1.0")
            .build()

        try {
            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string().orEmpty()
                if (body.isNotBlank() && !body.contains("AccountsSignIn", ignoreCase = true)) {
                    val parsed = parseHtmlContent(docId, body)
                    return@withContext Result.success(parsed)
                }
            }
        } catch (e: Exception) {
            // HTML export failed or connection refused; fall through to text or pub
        }

        // Try TXT export
        val txtUrl = "https://docs.google.com/document/d/$docId/export?format=txt"
        val txtRequest = Request.Builder()
            .url(txtUrl)
            .header("User-Agent", "Mozilla/5.0 (Android; Mobile) DocuBook/1.0")
            .build()

        try {
            val response = httpClient.newCall(txtRequest).execute()
            if (response.isSuccessful) {
                val body = response.body?.string().orEmpty()
                if (body.isNotBlank() && !body.contains("AccountsSignIn", ignoreCase = true)) {
                    val parsed = parsePlainTextContent(docId, body)
                    return@withContext Result.success(parsed)
                }
            }
        } catch (e: Exception) {
            // Both export endpoints failed
        }

        // If doc is private or export required login
        Result.failure(
            IOException(
                "Could not export document directly. Ensure link sharing is set to 'Anyone with the link can view' or open the Live Docs Editor tab to view and edit."
            )
        )
    }

    /**
     * Parses Google Docs exported HTML into semantic book elements.
     */
    fun parseHtmlContent(docId: String, html: String): BookContent {
        var docTitle = "Untitled Document"

        // Extract <title>...</title>
        val titleMatcher = Pattern.compile("<title>(.*?)</title>", Pattern.CASE_INSENSITIVE or Pattern.DOTALL).matcher(html)
        if (titleMatcher.find()) {
            val rawTitle = cleanHtmlEntities(titleMatcher.group(1)).trim()
            if (rawTitle.isNotEmpty()) {
                docTitle = rawTitle
            }
        }

        val elements = mutableListOf<BookElement>()
        val toc = mutableListOf<TocEntry>()

        // Remove <head>...</head> and script/style tags
        var bodyHtml = html.replace(Regex("(?s)<head.*?>.*?</head>"), "")
        bodyHtml = bodyHtml.replace(Regex("(?s)<style.*?>.*?</style>"), "")
        bodyHtml = bodyHtml.replace(Regex("(?s)<script.*?>.*?</script>"), "")

        // Regex for block-level tags: h1, h2, h3, p, blockquote, ul, ol, hr
        val blockPattern = Pattern.compile(
            "<(h1|h2|h3|h4|h5|h6|p|blockquote|ul|ol|hr)(?:\\s[^>]*)?>(.*?)(?:</\\1>|(?=<h1|<h2|<h3|<h4|<h5|<h6|<p|<blockquote|<ul|<ol|<hr|$))",
            Pattern.CASE_INSENSITIVE or Pattern.DOTALL
        )

        val matcher = blockPattern.matcher(bodyHtml)
        var isFirstInChapter = true

        while (matcher.find()) {
            val tag = matcher.group(1).lowercase()
            val inner = matcher.group(2) ?: ""
            val plain = cleanHtmlEntities(stripHtmlTags(inner)).trim()

            if (tag == "hr") {
                elements.add(BookElement.Divider)
                continue
            }

            if (plain.isBlank()) continue

            when {
                tag in listOf("h1", "h2") || isChapterHeader(plain) -> {
                    val chapterNum = extractChapterNumber(plain)
                    elements.add(
                        BookElement.ChapterTitle(
                            title = plain,
                            chapterNumber = chapterNum
                        )
                    )
                    toc.add(
                        TocEntry(
                            title = plain,
                            elementIndex = elements.size - 1,
                            level = if (tag == "h1") 1 else 2
                        )
                    )
                    isFirstInChapter = true
                }
                tag in listOf("h3", "h4", "h5", "h6") -> {
                    elements.add(BookElement.Heading(text = plain, level = tag[1].digitToInt()))
                    toc.add(
                        TocEntry(
                            title = plain,
                            elementIndex = elements.size - 1,
                            level = tag[1].digitToInt()
                        )
                    )
                    isFirstInChapter = false
                }
                tag == "blockquote" -> {
                    elements.add(BookElement.Blockquote(quote = plain))
                    isFirstInChapter = false
                }
                tag in listOf("ul", "ol") -> {
                    val liPattern = Pattern.compile("<li(?:\\s[^>]*)?>(.*?)</li>", Pattern.CASE_INSENSITIVE or Pattern.DOTALL)
                    val liMatcher = liPattern.matcher(inner)
                    val items = mutableListOf<String>()
                    while (liMatcher.find()) {
                        val liText = cleanHtmlEntities(stripHtmlTags(liMatcher.group(1))).trim()
                        if (liText.isNotEmpty()) items.add(liText)
                    }
                    if (items.isNotEmpty()) {
                        elements.add(BookElement.BulletList(items))
                    }
                    isFirstInChapter = false
                }
                tag == "p" -> {
                    elements.add(
                        BookElement.Paragraph(
                            text = plain,
                            isFirstOfChapter = isFirstInChapter
                        )
                    )
                    isFirstInChapter = false
                }
            }
        }

        if (elements.isEmpty()) {
            // Fallback plain text parse if no tags matched
            return parsePlainTextContent(docId, stripHtmlTags(html))
        }

        // If docTitle is still generic, take first heading if available
        if (docTitle.equals("Untitled Document", ignoreCase = true) && toc.isNotEmpty()) {
            docTitle = toc.first().title
        }

        return BookContent(
            docId = docId,
            title = docTitle,
            elements = elements,
            rawText = html,
            tableOfContents = toc,
            fetchedAt = System.currentTimeMillis()
        )
    }

    /**
     * Parses plain text content into chapters and paragraphs.
     */
    fun parsePlainTextContent(docId: String, text: String): BookContent {
        val lines = text.lines()
        val elements = mutableListOf<BookElement>()
        val toc = mutableListOf<TocEntry>()
        var title = "Google Doc"

        var currentPara = StringBuilder()
        var isFirstInChapter = true

        fun flushPara() {
            val content = currentPara.toString().trim()
            if (content.isNotEmpty()) {
                elements.add(
                    BookElement.Paragraph(
                        text = content,
                        isFirstOfChapter = isFirstInChapter
                    )
                )
                isFirstInChapter = false
            }
            currentPara = StringBuilder()
        }

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) {
                flushPara()
                continue
            }

            if (isChapterHeader(trimmed)) {
                flushPara()
                val chapterNum = extractChapterNumber(trimmed)
                elements.add(BookElement.ChapterTitle(title = trimmed, chapterNumber = chapterNum))
                toc.add(TocEntry(title = trimmed, elementIndex = elements.size - 1, level = 1))
                isFirstInChapter = true
                if (title == "Google Doc") {
                    title = trimmed
                }
            } else if (trimmed.startsWith("# ")) {
                flushPara()
                val head = trimmed.removePrefix("# ").trim()
                elements.add(BookElement.ChapterTitle(title = head))
                toc.add(TocEntry(title = head, elementIndex = elements.size - 1, level = 1))
                isFirstInChapter = true
                if (title == "Google Doc") title = head
            } else if (trimmed.startsWith("## ")) {
                flushPara()
                val head = trimmed.removePrefix("## ").trim()
                elements.add(BookElement.Heading(text = head, level = 2))
                toc.add(TocEntry(title = head, elementIndex = elements.size - 1, level = 2))
                isFirstInChapter = false
            } else if (trimmed.startsWith("---") || trimmed.startsWith("***")) {
                flushPara()
                elements.add(BookElement.Divider)
            } else if (trimmed.startsWith("> ")) {
                flushPara()
                elements.add(BookElement.Blockquote(quote = trimmed.removePrefix("> ").trim()))
                isFirstInChapter = false
            } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("• ")) {
                flushPara()
                elements.add(BookElement.BulletList(listOf(trimmed.substring(2).trim())))
                isFirstInChapter = false
            } else {
                if (currentPara.isNotEmpty()) currentPara.append(" ")
                currentPara.append(trimmed)
            }
        }
        flushPara()

        return BookContent(
            docId = docId,
            title = title,
            elements = elements,
            rawText = text,
            tableOfContents = toc,
            fetchedAt = System.currentTimeMillis()
        )
    }

    private fun isChapterHeader(text: String): Boolean {
        val lower = text.lowercase()
        return lower.startsWith("chapter ") ||
                lower.startsWith("chapter:") ||
                lower.startsWith("act ") ||
                lower.startsWith("prologue") ||
                lower.startsWith("epilogue") ||
                lower.startsWith("part ") ||
                lower.startsWith("book ")
    }

    private fun extractChapterNumber(text: String): Int? {
        val numPattern = Pattern.compile("(?i)(?:chapter|part|act|book)\\s+([0-9]+)")
        val m = numPattern.matcher(text)
        return if (m.find()) m.group(1)?.toIntOrNull() else null
    }

    private fun stripHtmlTags(html: String): String {
        return html.replace(Regex("<[^>]*>"), " ")
    }

    private fun cleanHtmlEntities(text: String): String {
        return text
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&mdash;", "—")
            .replace("&ndash;", "–")
            .replace("&hellip;", "…")
            .replace(Regex("\\s+"), " ")
    }

    /**
     * Built-in rich sample manuscripts so the user can test dual-page book reading instantly.
     */
    fun getSampleBooks(): List<BookContent> {
        return listOf(
            createOdysseySample(),
            createPhilosophySample(),
            createCollaborativeSpecSample()
        )
    }

    private fun createOdysseySample(): BookContent {
        val elements = listOf(
            BookElement.ChapterTitle("Prologue", subtitle = "The Whispering Dust"),
            BookElement.Paragraph(
                "Before the stars grew silent, the cartographers of Orion spent three centuries carving astronomical coordinates into the basalt cliffs of Kepler-452. They believed that light was not merely radiation, but the living memory of things that had refused to surrender to darkness.",
                isFirstOfChapter = true
            ),
            BookElement.Paragraph(
                "Commander Lyra Vance checked the quantum telemetry of the folding beacon. The ship’s twin wings flexed like the spine of an illuminated manuscript, each page of composite alloy reflecting the auroral curtain outside the bridge."
            ),
            BookElement.Blockquote(
                quote = "We do not navigate by compass or star; we navigate by the sentences written across the void by those who ventured before us.",
                attribution = "The Orion Stargazer’s Codex, 2842"
            ),
            BookElement.Paragraph(
                "\"Readings are steady, Lyra,\" said Kaelen, leaning over the holographic console. His hands drifted across the sensor bands with the instinctive rhythm of a pianist. \"The gravitational fold is holding. If the jump coordinates hold true, we will cross the Perseus spiral arm before the second watch.\""
            ),
            BookElement.Divider,
            BookElement.ChapterTitle("Chapter 1", subtitle = "The Folded Horizon", chapterNumber = 1),
            BookElement.Paragraph(
                "When a universe opens itself like a book, one does not simply step through; one reads oneself into the next chapter.",
                isFirstOfChapter = true
            ),
            BookElement.Paragraph(
                "The ship slipped between the folds of spacetime with a sound like wind rushing through an ancient library. On both sides of the viewing pane, galaxies unspooled in dual ribbons of azure and gold, perfect mirror images reflected across an invisible spine in the vacuum."
            ),
            BookElement.BulletList(
                listOf(
                    "Atmospheric integrity: 100% nominal",
                    "Gravitational fold index: 1.414 (Dual Spread parity)",
                    "Sub-ether transmitter: Synced with Earth Docs server"
                )
            ),
            BookElement.Paragraph(
                "Lyra adjusted her flight gloves. Every fold in the ship’s hull was engineered to absorb the tidal shear of transition. Just as a heavy hardcover protects the delicate parchment bound inside, the outer bulkheads bore the scorch marks of supernovas long extinguished."
            ),
            BookElement.ChapterTitle("Chapter 2", subtitle = "The Archivist of Altair", chapterNumber = 2),
            BookElement.Paragraph(
                "Deep within the crystalline archive of Altair IV, millions of texts hung suspended in electromagnetic amber. Scholars sat in concentric circles under a vaulted dome of black obsidian, turning pages made of polarized light.",
                isFirstOfChapter = true
            ),
            BookElement.Paragraph(
                "\"You seek the living document,\" said the elder archivist, his robes rustling against the stone floor. \"Many come asking for fixed histories, but history is not a statue. It is an editable ledger, written in real time by every breath you draw in deep space.\""
            ),
            BookElement.Paragraph(
                "He reached into the light and pulled free a manuscript that glowed with warm parchment tones. As Lyra watched, the script rearranged itself before her eyes, sentences completing themselves as if whispered into existence from afar."
            ),
            BookElement.Blockquote(
                quote = "A true book is never finished. It waits for the next pair of eyes to unfold its meaning.",
                attribution = "Archivist Theron"
            )
        )

        val toc = listOf(
            TocEntry("Prologue: The Whispering Dust", 0, 1),
            TocEntry("Chapter 1: The Folded Horizon", 5, 1),
            TocEntry("Chapter 2: The Archivist of Altair", 9, 1)
        )

        return BookContent(
            docId = "sample_odyssey_orion",
            title = "The Chronos Odyssey",
            author = "Lyra Vance & AI Studio",
            elements = elements,
            tableOfContents = toc,
            fetchedAt = System.currentTimeMillis()
        )
    }

    private fun createPhilosophySample(): BookContent {
        val elements = listOf(
            BookElement.ChapterTitle("The Book & The Fold", subtitle = "An Essay on Digital Physicality"),
            BookElement.Paragraph(
                "For five hundred years since Gutenberg, the codex has survived unchanged. Not because technology lacked ambition, but because two facing pages form the natural geometry of human contemplation.",
                isFirstOfChapter = true
            ),
            BookElement.Paragraph(
                "Our eyes were not designed for an endless, anxiety-inducing vertical scroll. Scrolling is the gesture of consumption; page turning is the gesture of contemplation. When a page turns, time hesitates. The mind digests what came before and prepares itself for revelation."
            ),
            BookElement.Blockquote(
                quote = "The gutter between two open pages is not empty space—it is the hinge upon which memory turns.",
                attribution = "Aldus Manutius, Venice 1501"
            ),
            BookElement.ChapterTitle("The Dual-Screen Renaissance", chapterNumber = 2),
            BookElement.Paragraph(
                "With the arrival of modern folding devices, the book returns to its rightful form. When you open a foldable display, the mechanical hinge echoes the leather binding of a 16th-century octavo.",
                isFirstOfChapter = true
            ),
            BookElement.Paragraph(
                "On the left, the premise; on the right, the consequence. Text breathes. The margins provide shelter from the noise of the digital world."
            ),
            BookElement.BulletList(
                listOf(
                    "Balance: Symmetrical margins relax eye strain",
                    "Pacing: Page breaks create natural cognitive milestones",
                    "Permanence: Words stay in their physical position on the sheet"
                )
            )
        )

        val toc = listOf(
            TocEntry("The Book & The Fold", 0, 1),
            TocEntry("The Dual-Screen Renaissance", 3, 1)
        )

        return BookContent(
            docId = "sample_philosophy",
            title = "The Architecture of Reading",
            author = "Prof. Marcus H. Sterling",
            elements = elements,
            tableOfContents = toc,
            fetchedAt = System.currentTimeMillis()
        )
    }

    private fun createCollaborativeSpecSample(): BookContent {
        val elements = listOf(
            BookElement.ChapterTitle("Project Zenith", subtitle = "Live Collaborative Specification"),
            BookElement.Paragraph(
                "This document is a live collaborative spec. Edits made by authors in Google Docs are immediately synchronized into this book layout with real-time change detection.",
                isFirstOfChapter = true
            ),
            BookElement.Heading("1. Architectural Overview", level = 2),
            BookElement.Paragraph(
                "The DocuBook engine bridges the cloud flexibility of Google Docs with the typographic elegance of a physical volume. Writers edit in their favorite word processor while readers enjoy an uninterrupted literary experience."
            ),
            BookElement.BulletList(
                listOf(
                    "Instant parsing of public and shared Google Docs URLs",
                    "Adaptive dual-page spreads for Fold 8 and wide screens",
                    "Interactive page turning gestures with realistic 3D curl",
                    "Background live sync polling with zero-flicker re-pagination"
                )
            ),
            BookElement.Heading("2. Fold 8 Target Experience", level = 2),
            BookElement.Paragraph(
                "When the Galaxy Z Fold 8 is unfolded, the viewport expands beyond 600dp. DocuBook splits content into an authentic two-page spread with center spine shadow and subtle page edge depth."
            ),
            BookElement.Blockquote(
                quote = "Every collaborative document deserves to be read with the dignity of a finished masterpiece.",
                attribution = "Design Principles, 2026"
            )
        )

        val toc = listOf(
            TocEntry("Project Zenith", 0, 1),
            TocEntry("1. Architectural Overview", 2, 2),
            TocEntry("2. Fold 8 Target Experience", 4, 2)
        )

        return BookContent(
            docId = "sample_project_zenith",
            title = "Project Zenith Spec",
            author = "Engineering Team",
            elements = elements,
            tableOfContents = toc,
            fetchedAt = System.currentTimeMillis()
        )
    }
}
