package com.example.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.LiveSyncGreen

@Composable
fun ReaderTopBar(
    title: String,
    syncStatus: SyncStatus,
    isDualPage: Boolean,
    visible: Boolean,
    autoRefreshEnabled: Boolean,
    soundEnabled: Boolean,
    uiThemeMode: UiThemeMode = UiThemeMode.AMOLED_NIGHT,
    onBack: () -> Unit,
    onToggleAutoRefresh: () -> Unit,
    onToggleSound: () -> Unit,
    onCycleUiThemeMode: () -> Unit = {},
    onOpenLiveEditor: () -> Unit,
    onManualSync: () -> Unit,
    onOpenToc: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showMoreMenu by remember { mutableStateOf(false) }

    val isDay = uiThemeMode == UiThemeMode.LIQUID_GLASS_DAY

    val barBgColor = if (isDay) Color(0xEBFFFFFF) else Color.Black.copy(alpha = 0.96f)
    val barBorder = if (isDay) {
        androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0x7094A3B8)))
        )
    } else {
        androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E1E))
    }
    // Any light text should be dark in day mode so it is visible!
    val barTextColor = if (isDay) Color(0xFF0F172A) else Color(0xFFEDEDED)
    val barSecondaryColor = if (isDay) Color(0xFF475569) else Color(0xFFA0A0A0)

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically { -it },
        exit = fadeOut() + slideOutVertically { -it },
        modifier = modifier
    ) {
        Surface(
            color = barBgColor,
            border = barBorder,
            tonalElevation = if (isDay) 0.dp else 4.dp,
            shadowElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
        ) {
            // Sleek single-line condensed row (approx 44dp height)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back Button
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("reader_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Return to Bookshelf",
                        tint = barTextColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Condensed Single-Line Title with inline sync indicator
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = barTextColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Minimal inline sync dot
                    CompactSyncDot(
                        syncStatus = syncStatus,
                        isDay = isDay,
                        onClick = onManualSync
                    )
                }

                // Compact action buttons row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    // Auto-Refresh Quick Toggle (compact icon with spinning active state)
                    CompactAutoRefreshToggle(
                        enabled = autoRefreshEnabled,
                        onToggle = onToggleAutoRefresh
                    )

                    // Text Search
                    IconButton(
                        onClick = onOpenSearch,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("open_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search text in book",
                            tint = barTextColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Table of Contents
                    IconButton(
                        onClick = onOpenToc,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("open_toc_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.MenuBook,
                            contentDescription = "Table of contents",
                            tint = barTextColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Settings
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("open_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Book settings",
                            tint = barTextColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Compact More Overflow Menu
                    Box {
                        IconButton(
                            onClick = { showMoreMenu = true },
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("reader_overflow_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "More actions",
                                tint = barTextColor,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Edit in Google Docs") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                },
                                onClick = {
                                    showMoreMenu = false
                                    onOpenLiveEditor()
                                }
                            )

                            DropdownMenuItem(
                                text = { Text(if (soundEnabled) "Mute Sound" else "Enable Sound") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (soundEnabled) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = null
                                    )
                                },
                                onClick = {
                                    showMoreMenu = false
                                    onToggleSound()
                                }
                            )

                            DropdownMenuItem(
                                text = { Text("Refresh Now") },
                                leadingIcon = {
                                    Icon(Icons.Default.Refresh, contentDescription = null)
                                },
                                onClick = {
                                    showMoreMenu = false
                                    onManualSync()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompactAutoRefreshToggle(
    enabled: Boolean,
    onToggle: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "auto_refresh_spin")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin"
    )

    IconButton(
        onClick = onToggle,
        modifier = Modifier
            .size(38.dp)
            .testTag("auto_refresh_toggle_button")
    ) {
        Icon(
            imageVector = Icons.Default.Autorenew,
            contentDescription = if (enabled) "Auto-Sync Active (tap to disable)" else "Auto-Sync Inactive (tap to enable)",
            tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier
                .size(20.dp)
                .then(if (enabled) Modifier.rotate(rotation) else Modifier)
        )
    }
}

@Composable
fun CompactSyncDot(
    syncStatus: SyncStatus,
    isDay: Boolean = false,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alphaAnim by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    val spinTransition = rememberInfiniteTransition(label = "spin")
    val rotation by spinTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Surface(
        color = if (isDay) Color(0x35CBD5E1) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .testTag("live_sync_badge")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            when (syncStatus) {
                is SyncStatus.Syncing -> {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Syncing",
                        tint = LiveSyncGreen,
                        modifier = Modifier
                            .size(9.dp)
                            .rotate(rotation)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "SYNC",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = LiveSyncGreen
                    )
                }
                is SyncStatus.Offline -> {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .background(Color(0xFFE6A23C), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "OFFLINE",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE6A23C)
                    )
                }
                is SyncStatus.Error -> {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .background(MaterialTheme.colorScheme.error, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "ERROR",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                else -> {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .background(LiveSyncGreen.copy(alpha = alphaAnim), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "LIVE",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDay) Color(0xFF0F172A) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ReaderBottomBar(
    currentSpreadIndex: Int,
    totalSpreads: Int,
    currentSpread: BookSpread?,
    visible: Boolean,
    isBookmarked: Boolean,
    uiThemeMode: UiThemeMode = UiThemeMode.AMOLED_NIGHT,
    onToggleBookmark: () -> Unit,
    onSeekSpread: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val isDay = uiThemeMode == UiThemeMode.LIQUID_GLASS_DAY

    val barBgColor = if (isDay) Color(0xEBFFFFFF) else Color.Black.copy(alpha = 0.96f)
    val barBorder = if (isDay) {
        androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0x7094A3B8)))
        )
    } else {
        androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E1E))
    }
    val barTextColor = if (isDay) Color(0xFF0F172A) else Color(0xFFEDEDED)
    val barSecondaryColor = if (isDay) Color(0xFF475569) else Color(0xFFA0A0A0)

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically { it },
        exit = fadeOut() + slideOutVertically { it },
        modifier = modifier
    ) {
        Surface(
            color = barBgColor,
            border = barBorder,
            tonalElevation = if (isDay) 0.dp else 6.dp,
            shadowElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                // Page slider and reading progress descriptor
                val (pageLabel, progressPercent) = if (currentSpread != null) {
                    val totalP = currentSpread.leftPage.totalPages.coerceAtLeast(1)
                    val currP = if (currentSpread.rightPage != null) currentSpread.rightPage.pageNumber else currentSpread.leftPage.pageNumber
                    val percent = ((currP.toFloat() / totalP.toFloat()) * 100).toInt()
                    val text = if (currentSpread.isDualPage && currentSpread.rightPage != null) {
                        "Pages ${currentSpread.leftPage.pageNumber}-${currentSpread.rightPage.pageNumber} of $totalP ($percent%)"
                    } else {
                        "Page ${currentSpread.leftPage.pageNumber} of $totalP ($percent%)"
                    }
                    Pair(text, percent)
                } else {
                    Pair("Spread ${currentSpreadIndex + 1} of $totalSpreads", 0)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = pageLabel,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = barTextColor
                        )
                        val estMinutesLeft = ((totalSpreads - currentSpreadIndex).coerceAtLeast(1) * 0.7f).toInt().coerceAtLeast(1)
                        Text(
                            text = "Reading progress: $progressPercent% • ~$estMinutesLeft min remaining",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = barSecondaryColor
                        )
                    }

                    // Bookmark toggle
                    IconButton(
                        onClick = onToggleBookmark,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("reader_bookmark_toggle")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = if (isBookmarked) "Remove bookmark" else "Bookmark this page",
                            tint = if (isBookmarked) MaterialTheme.colorScheme.primary else barSecondaryColor
                        )
                    }
                }

                // Smooth page slider
                if (totalSpreads > 1) {
                    Slider(
                        value = currentSpreadIndex.toFloat(),
                        onValueChange = { onSeekSpread(it.toInt()) },
                        valueRange = 0f..(totalSpreads - 1).toFloat(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reader_page_slider")
                    )
                }

                // Condensed Page Position Indicator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Spread ${currentSpreadIndex + 1} of $totalSpreads",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = barSecondaryColor
                    )
                }
            }
        }
    }
}
