package com.example.ui

import androidx.activity.compose.BackHandler
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.editor.GoogleDocsWebView
import com.example.model.BookContent
import com.example.parser.GoogleDocsService
import com.example.reader.*
import com.example.viewmodel.DocuBookViewModel
import kotlinx.coroutines.launch

@Composable
fun ReaderScreen(
    viewModel: DocuBookViewModel,
    onNavigateBackToShelf: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val activeBook = uiState.activeBookContent
    val spreads = uiState.spreads
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    BackHandler {
        when {
            uiState.isTocOpen -> viewModel.closeToc()
            uiState.isSettingsOpen -> viewModel.closeSettings()
            uiState.isSearchOpen -> viewModel.closeSearch()
            uiState.isInLiveEditorMode -> viewModel.closeLiveEditor()
            else -> onNavigateBackToShelf()
        }
    }

    if (activeBook == null || spreads.isEmpty()) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    // Measure window constraints to detect Fold 8 open state (width >= 600dp)
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val widthDp = maxWidth.value
        val heightDp = maxHeight.value
        LaunchedEffect(widthDp, heightDp, uiState.preferences.foldDisplayMode) {
            viewModel.updateWindowDimensions(widthDp, heightDp)
        }

        // Pager State for book spreads
        val pagerState = rememberPagerState(
            initialPage = uiState.currentSpreadIndex.coerceIn(0, (spreads.size - 1).coerceAtLeast(0)),
            pageCount = { spreads.size }
        )

        // Sync when ViewModel updates currentSpreadIndex externally (e.g. from TOC jump)
        LaunchedEffect(uiState.currentSpreadIndex) {
            if (pagerState.currentPage != uiState.currentSpreadIndex && uiState.currentSpreadIndex < spreads.size) {
                pagerState.scrollToPage(uiState.currentSpreadIndex)
            }
        }

        val currentSpread = spreads.getOrNull(pagerState.currentPage)
        val isCurrentBookmarked = currentSpread?.let {
            viewModel.isPageBookmarked(it.leftPage.pageNumber) ||
                    (it.rightPage != null && viewModel.isPageBookmarked(it.rightPage.pageNumber))
        } ?: false

        if (uiState.isInLiveEditorMode && uiState.activeDocSource != null) {
            // Live Editable Google Docs View
            val webUrl = GoogleDocsService.getDocsWebUrl(uiState.activeDocSource!!.id)
            GoogleDocsWebView(
                docUrl = webUrl,
                docTitle = activeBook.title,
                onBackToBook = { viewModel.closeLiveEditor() },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Main Book Reader with Page Turn Pager
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(uiState.preferences.paperTheme.backgroundColor)
            ) {
                BookTurnPager(
                    spreads = spreads,
                    pagerState = pagerState,
                    preferences = uiState.preferences,
                    isBookmarked = { pageNum -> viewModel.isPageBookmarked(pageNum) },
                    onToggleBookmark = { pageNum -> viewModel.toggleBookmark(pageNum) },
                    onToggleControls = { viewModel.toggleControls() },
                    onPageTurned = { newPageIndex ->
                        viewModel.setSpreadIndex(newPageIndex)
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Top Header HUD
                ReaderTopBar(
                    title = activeBook.title,
                    syncStatus = uiState.syncStatus,
                    isDualPage = uiState.isDualPageActive,
                    visible = uiState.isControlsVisible,
                    autoRefreshEnabled = uiState.preferences.autoRefreshEnabled,
                    soundEnabled = uiState.preferences.soundEnabled,
                    uiThemeMode = uiState.preferences.uiThemeMode,
                    onBack = onNavigateBackToShelf,
                    onToggleAutoRefresh = { viewModel.toggleAutoRefresh() },
                    onToggleSound = { viewModel.toggleSound() },
                    onCycleUiThemeMode = { viewModel.cycleUiThemeMode() },
                    onOpenLiveEditor = {
                        val source = uiState.activeDocSource
                        if (source != null && !source.isSample) {
                            val url = GoogleDocsService.getDocsWebUrl(source.id)
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            // Android resolves the installed Google Docs app when configured for Docs links.
                            context.startActivity(intent)
                        }
                    },
                    onManualSync = { viewModel.manualSync() },
                    onOpenToc = { viewModel.openToc() },
                    onOpenSearch = { viewModel.openSearch() },
                    onOpenSettings = { viewModel.openSettings() },
                    modifier = Modifier.align(Alignment.TopCenter)
                )

                // Bottom Navigation & Slider HUD
                ReaderBottomBar(
                    currentSpreadIndex = pagerState.currentPage,
                    totalSpreads = spreads.size,
                    currentSpread = currentSpread,
                    visible = uiState.isControlsVisible,
                    isBookmarked = isCurrentBookmarked,
                    uiThemeMode = uiState.preferences.uiThemeMode,
                    onToggleBookmark = {
                        currentSpread?.let {
                            viewModel.toggleBookmark(it.leftPage.pageNumber)
                        }
                    },
                    onSeekSpread = { targetIndex ->
                        coroutineScope.launch {
                            pagerState.scrollToPage(targetIndex)
                        }
                    },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }

        // Settings Sheet
        if (uiState.isSettingsOpen) {
            ReaderSettingsSheet(
                preferences = uiState.preferences,
                onUpdatePreferences = { newPrefs -> viewModel.updatePreferences(newPrefs) },
                onOpenSearch = { viewModel.openSearch() },
                onDismiss = { viewModel.closeSettings() }
            )
        }

        // Text Search Sheet
        if (uiState.isSearchOpen) {
            TextSearchSheet(
                searchState = uiState.searchState,
                onQueryChanged = { viewModel.performSearch(it) },
                onSelectMatch = { viewModel.selectSearchMatch(it) },
                onNextMatch = { viewModel.nextSearchMatch() },
                onPrevMatch = { viewModel.prevSearchMatch() },
                onDismiss = { viewModel.closeSearch() }
            )
        }

        // Table of Contents Sheet
        if (uiState.isTocOpen) {
            TableOfContentsSheet(
                content = activeBook,
                bookmarkedPages = uiState.activeDocSource?.bookmarkPages ?: emptySet(),
                onJumpToPage = { pageNum -> viewModel.jumpToPage(pageNum) },
                onRemoveBookmark = { pageNum -> viewModel.toggleBookmark(pageNum) },
                onDismiss = { viewModel.closeToc() }
            )
        }
    }
}
