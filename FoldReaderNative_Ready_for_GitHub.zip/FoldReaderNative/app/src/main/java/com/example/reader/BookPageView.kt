package com.example.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.LoraFontFamily
import com.example.ui.theme.PlayfairFontFamily

@Composable
fun BookSpreadView(
    spread: BookSpread,
    preferences: ReaderPreferences,
    isBookmarked: (Int) -> Boolean,
    onToggleBookmark: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = preferences.paperTheme

    if (spread.isDualPage && spread.rightPage != null) {
        // Dual-Page Spread (Open Fold 8 / Wide Screen)
        Row(
            modifier = modifier
                .fillMaxSize()
                .background(theme.backgroundColor)
                .testTag("dual_page_spread_${spread.spreadIndex}"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Page
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                BookSinglePageView(
                    page = spread.leftPage,
                    preferences = preferences,
                    isLeftPageInSpread = true,
                    isBookmarked = isBookmarked(spread.leftPage.pageNumber),
                    onToggleBookmark = { onToggleBookmark(spread.leftPage.pageNumber) },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Central Book Spine & Crease Shadow (Authentic Book Binding)
            BookSpineGutter(
                theme = theme,
                modifier = Modifier
                    .width(24.dp)
                    .fillMaxHeight()
            )

            // Right Page
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                BookSinglePageView(
                    page = spread.rightPage,
                    preferences = preferences,
                    isLeftPageInSpread = false,
                    isBookmarked = isBookmarked(spread.rightPage.pageNumber),
                    onToggleBookmark = { onToggleBookmark(spread.rightPage.pageNumber) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    } else {
        // Single-Page View (Folded / Compact Mode)
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(theme.backgroundColor)
                .testTag("single_page_spread_${spread.spreadIndex}")
        ) {
            BookSinglePageView(
                page = spread.leftPage,
                preferences = preferences,
                isLeftPageInSpread = false,
                isBookmarked = isBookmarked(spread.leftPage.pageNumber),
                onToggleBookmark = { onToggleBookmark(spread.leftPage.pageNumber) },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/**
 * The physical book spine gutter with dual shadows simulating pages curving into the binding.
 */
@Composable
fun BookSpineGutter(
    theme: PaperTheme,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        theme.spineShadowColor.copy(alpha = 0.35f),
                        theme.spineShadowColor.copy(alpha = 0.65f),
                        Color(0x33000000),
                        theme.spineShadowColor.copy(alpha = 0.65f),
                        theme.spineShadowColor.copy(alpha = 0.35f),
                        Color.Transparent
                    )
                )
            )
            .drawBehind {
                // Subtle fine vertical thread line down the center binding
                val midX = size.width / 2f
                drawLine(
                    color = theme.borderColor.copy(alpha = 0.5f),
                    start = Offset(midX, 0f),
                    end = Offset(midX, size.height),
                    strokeWidth = 1.dp.toPx()
                )
            }
    )
}

@Composable
fun BookSinglePageView(
    page: BookPage,
    preferences: ReaderPreferences,
    isLeftPageInSpread: Boolean,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = preferences.paperTheme
    val marginPadding = preferences.marginSize.paddingDp.dp

    val bodyFontFamily = when (preferences.fontChoice) {
        FontChoice.PLAYFAIR_LORA -> LoraFontFamily
        FontChoice.SYSTEM_SERIF -> FontFamily.Serif
        FontChoice.SYSTEM_SANS -> FontFamily.SansSerif
        FontChoice.MONOSPACE -> FontFamily.Monospace
    }

    val displayFontFamily = when (preferences.fontChoice) {
        FontChoice.PLAYFAIR_LORA -> PlayfairFontFamily
        FontChoice.SYSTEM_SERIF -> FontFamily.Serif
        FontChoice.SYSTEM_SANS -> FontFamily.SansSerif
        FontChoice.MONOSPACE -> FontFamily.Monospace
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(
                start = if (isLeftPageInSpread) marginPadding else (marginPadding / 2 + 8.dp),
                end = if (!isLeftPageInSpread) marginPadding else (marginPadding / 2 + 8.dp),
                top = 20.dp,
                bottom = 20.dp
            )
    ) {
        // Bookmark Ribbon Tab in Top Corner
        if (isBookmarked) {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = "Bookmarked",
                tint = theme.accentColor,
                modifier = Modifier
                    .align(if (isLeftPageInSpread) Alignment.TopStart else Alignment.TopEnd)
                    .size(24.dp)
            )
        }

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Running Header (except on Cover Page)
            if (!page.isCover) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = if (isLeftPageInSpread) Arrangement.Start else Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = page.runningHeader,
                        color = theme.secondaryTextColor,
                        fontFamily = displayFontFamily,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Main Page Content Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = if (page.isCover) Alignment.Center else Alignment.TopStart
            ) {
                if (page.isCover) {
                    CoverPageLayout(
                        page = page,
                        theme = theme,
                        displayFont = displayFontFamily,
                        bodyFont = bodyFontFamily
                    )
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy((preferences.fontSizeSp * 0.75f).dp)
                    ) {
                        for (element in page.elements) {
                            RenderBookElement(
                                element = element,
                                preferences = preferences,
                                theme = theme,
                                displayFont = displayFontFamily,
                                bodyFont = bodyFontFamily
                            )
                        }
                    }
                }
            }

            // Running Footer: Page Number and Reading Progress
            if (!page.isCover) {
                val progressPercent = ((page.pageNumber.toFloat() / page.totalPages.coerceAtLeast(1).toFloat()) * 100).toInt()
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isLeftPageInSpread) "$progressPercent% read" else "",
                            color = theme.secondaryTextColor.copy(alpha = 0.7f),
                            fontFamily = displayFontFamily,
                            fontSize = 10.sp
                        )

                        Text(
                            text = "— ${page.pageNumber} —",
                            color = theme.secondaryTextColor,
                            fontFamily = displayFontFamily,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp
                        )

                        Text(
                            text = if (!isLeftPageInSpread) "$progressPercent% read" else "",
                            color = theme.secondaryTextColor.copy(alpha = 0.7f),
                            fontFamily = displayFontFamily,
                            fontSize = 10.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Minimalist Reading Progress Line Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(1.5.dp)
                            .background(theme.borderColor.copy(alpha = 0.4f), RoundedCornerShape(1.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progressPercent / 100f)
                                .fillMaxHeight()
                                .background(theme.accentColor, RoundedCornerShape(1.dp))
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun CoverPageLayout(
    page: BookPage,
    theme: PaperTheme,
    displayFont: FontFamily,
    bodyFont: FontFamily
) {
    val titleElement = page.elements.filterIsInstance<BookElement.ChapterTitle>().firstOrNull()
    val titleText = titleElement?.title ?: page.runningHeader
    val subtitleText = titleElement?.subtitle ?: "Live Google Docs Manuscript"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Decorative Headpiece Fleuron
        Text(
            text = "❦",
            color = theme.accentColor,
            fontSize = 28.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Ornamental frame around title
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .border(
                    width = 1.5.dp,
                    color = theme.borderColor,
                    shape = RoundedCornerShape(4.dp)
                )
                .padding(horizontal = 20.dp, vertical = 28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = titleText,
                    color = theme.textColor,
                    fontFamily = displayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 26.sp,
                    lineHeight = 34.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .width(48.dp)
                        .height(1.dp)
                        .background(theme.accentColor)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = subtitleText,
                    color = theme.secondaryTextColor,
                    fontFamily = bodyFont,
                    fontStyle = FontStyle.Italic,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Badge
        Surface(
            color = theme.borderColor.copy(alpha = 0.35f),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = "SYNCHRONIZED DOC",
                color = theme.secondaryTextColor,
                fontFamily = displayFont,
                fontSize = 10.sp,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun RenderBookElement(
    element: BookElement,
    preferences: ReaderPreferences,
    theme: PaperTheme,
    displayFont: FontFamily,
    bodyFont: FontFamily
) {
    val fontSize = preferences.fontSizeSp.sp
    val lineHeight = (preferences.fontSizeSp * preferences.lineSpacingMultiplier).sp

    when (element) {
        is BookElement.ChapterTitle -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = element.title,
                    color = theme.textColor,
                    fontFamily = displayFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = (preferences.fontSizeSp + 6).sp,
                    lineHeight = (preferences.fontSizeSp + 12).sp,
                    textAlign = TextAlign.Center
                )

                if (!element.subtitle.isNullOrBlank()) {
                    Text(
                        text = element.subtitle,
                        color = theme.secondaryTextColor,
                        fontFamily = bodyFont,
                        fontStyle = FontStyle.Italic,
                        fontSize = (preferences.fontSizeSp - 1).sp,
                        modifier = Modifier.padding(top = 4.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        is BookElement.Heading -> {
            val headSize = when (element.level) {
                1 -> preferences.fontSizeSp + 5
                2 -> preferences.fontSizeSp + 3
                else -> preferences.fontSizeSp + 1
            }.sp

            Text(
                text = element.text,
                color = theme.textColor,
                fontFamily = displayFont,
                fontWeight = FontWeight.SemiBold,
                fontSize = headSize,
                lineHeight = (headSize.value * 1.3f).sp,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
        }

        is BookElement.Paragraph -> {
            val text = element.text
            if (element.isFirstOfChapter && preferences.dropCapsEnabled && text.isNotBlank()) {
                // Drop Cap formatting for the first letter
                val firstChar = text.take(1)
                val remaining = text.drop(1)

                val annotated = buildAnnotatedString {
                    withStyle(
                        SpanStyle(
                            fontFamily = displayFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = (preferences.fontSizeSp * 2.4f).sp,
                            color = theme.accentColor
                        )
                    ) {
                        append(firstChar)
                    }
                    withStyle(
                        SpanStyle(
                            fontFamily = bodyFont,
                            fontSize = fontSize,
                            color = theme.textColor
                        )
                    ) {
                        append(remaining)
                    }
                }

                Text(
                    text = annotated,
                    lineHeight = lineHeight,
                    textAlign = TextAlign.Start,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Text(
                    text = text,
                    color = theme.textColor,
                    fontFamily = bodyFont,
                    fontSize = fontSize,
                    lineHeight = lineHeight,
                    textAlign = TextAlign.Start,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        is BookElement.Blockquote -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .fillMaxHeight()
                        .background(theme.accentColor)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "“${element.quote}”",
                        color = theme.textColor.copy(alpha = 0.9f),
                        fontFamily = bodyFont,
                        fontStyle = FontStyle.Italic,
                        fontSize = (preferences.fontSizeSp - 0.5f).sp,
                        lineHeight = lineHeight
                    )
                    if (!element.attribution.isNullOrBlank()) {
                        Text(
                            text = "— ${element.attribution}",
                            color = theme.secondaryTextColor,
                            fontFamily = displayFont,
                            fontSize = (preferences.fontSizeSp - 3).sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        is BookElement.BulletList -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (item in element.items) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "◆",
                            color = theme.accentColor,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(top = 6.dp, end = 8.dp)
                        )
                        Text(
                            text = item,
                            color = theme.textColor,
                            fontFamily = bodyFont,
                            fontSize = fontSize,
                            lineHeight = lineHeight
                        )
                    }
                }
            }
        }

        BookElement.Divider -> {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(modifier = Modifier.width(32.dp).height(1.dp).background(theme.borderColor))
                    Text(text = "❦", color = theme.accentColor, fontSize = 14.sp)
                    Box(modifier = Modifier.width(32.dp).height(1.dp).background(theme.borderColor))
                }
            }
        }
    }
}
