package com.example.reader

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.PagerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import com.example.model.BookSpread
import com.example.model.ReaderPreferences
import com.example.model.PageAnimationType
import com.example.model.UiThemeMode
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

enum class DragCorner {
    BOTTOM_RIGHT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    TOP_LEFT
}

// Gentle, organic physical book-page easing
private val OrganicPageTurnEasing = CubicBezierEasing(0.20f, 1f, 0.35f, 1f)

@Composable
fun BookTurnPager(
    spreads: List<BookSpread>,
    pagerState: PagerState,
    preferences: ReaderPreferences,
    isBookmarked: (Int) -> Boolean,
    onToggleBookmark: (Int) -> Unit,
    onToggleControls: () -> Unit,
    onPageTurned: ((Int) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    // Smooth turn progress (0f = rest/flat, 1f = fully turned over to destination spread)
    val turnProgress = remember { Animatable(0f) }
    var activeCorner by remember { mutableStateOf<DragCorner?>(null) }
    var targetSpreadIndex by remember { mutableIntStateOf(-1) }

    // Always read current page dynamically from pagerState
    val currentSpreadIndex = pagerState.currentPage.coerceIn(0, (spreads.size - 1).coerceAtLeast(0))
    val currentSpread = spreads.getOrNull(currentSpreadIndex)
    val isDualPage = currentSpread?.isDualPage == true && currentSpread.rightPage != null

    val isCurling = activeCorner != null && targetSpreadIndex in spreads.indices
    val isTurningForward = activeCorner == DragCorner.BOTTOM_RIGHT || activeCorner == DragCorner.TOP_RIGHT

    // Determine reader backdrop based on UI theme mode
    val backdropColor = when (preferences.uiThemeMode) {
        UiThemeMode.LIQUID_GLASS_DAY -> Color(0xFFF1F5F9)
        UiThemeMode.AMOLED_NIGHT -> Color.Black
    }

    // Keep pagerState, spreads, and callbacks in latest State to avoid closure stale state
    val latestPagerState by rememberUpdatedState(pagerState)
    val latestSpreads by rememberUpdatedState(spreads)
    val latestIsDualPage by rememberUpdatedState(isDualPage)
    val latestOnPageTurned by rememberUpdatedState(onPageTurned)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(backdropColor)
            .pointerInput(currentSpreadIndex, spreads.size, preferences.pageAnimationType) {
                val screenW = size.width.toFloat()
                val screenH = size.height.toFloat()

                if (preferences.pageAnimationType == PageAnimationType.INSTANT) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val x0 = down.position.x
                        var dx = 0f
                        do {
                            val event = awaitPointerEvent()
                            val pointer = event.changes.firstOrNull { it.id == down.id } ?: break
                            dx += pointer.positionChange().x
                        } while (event.changes.any { it.pressed })
                        val current = latestPagerState.currentPage
                        val target = when {
                            dx < -45f || (kotlin.math.abs(dx) < 18f && x0 > screenW * .82f) -> current + 1
                            dx > 45f || (kotlin.math.abs(dx) < 18f && x0 < screenW * .18f) -> current - 1
                            else -> current
                        }
                        if (target != current && target in latestSpreads.indices) {
                            latestPagerState.scrollToPage(target)
                            latestOnPageTurned?.invoke(target)
                            PageSoundManager.playPageTurnSound(preferences.pageSoundType, preferences.soundEnabled)
                        } else if (target == current && kotlin.math.abs(dx) < 18f) {
                            onToggleControls()
                        }
                    }
                } else {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startTime = System.currentTimeMillis()
                    val startPos = down.position

                    val activeCurrentIndex = latestPagerState.currentPage
                    val totalSpreads = latestSpreads.size
                    val dualActive = latestIsDualPage

                    val isRightSide = startPos.x >= (if (dualActive) screenW * 0.5f else screenW * 0.4f)
                    val isBottom = startPos.y >= screenH * 0.5f

                    var corner: DragCorner? = null
                    var targetIdx = -1

                    if (isRightSide) {
                        if (activeCurrentIndex < totalSpreads - 1) {
                            corner = if (isBottom) DragCorner.BOTTOM_RIGHT else DragCorner.TOP_RIGHT
                            targetIdx = activeCurrentIndex + 1
                        }
                    } else {
                        if (activeCurrentIndex > 0) {
                            corner = if (isBottom) DragCorner.BOTTOM_LEFT else DragCorner.TOP_LEFT
                            targetIdx = activeCurrentIndex - 1
                        }
                    }

                    var totalDx = 0f
                    var totalDy = 0f
                    var isDrag = false

                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break

                        val delta = change.positionChange()
                        totalDx += delta.x
                        totalDy += delta.y

                        if (!isDrag && (abs(totalDx) > 8f || abs(totalDy) > 8f)) {
                            isDrag = true
                            if (corner != null && targetIdx in 0 until totalSpreads) {
                                activeCorner = corner
                                targetSpreadIndex = targetIdx
                            }
                        }

                        if (isDrag && corner != null && targetIdx in 0 until totalSpreads) {
                            change.consume()
                            val pageEffectiveWidth = if (dualActive) screenW * 0.5f else screenW

                            val rawProgress = if (corner == DragCorner.BOTTOM_RIGHT || corner == DragCorner.TOP_RIGHT) {
                                (-totalDx / pageEffectiveWidth).coerceIn(0f, 1f)
                            } else {
                                (totalDx / pageEffectiveWidth).coerceIn(0f, 1f)
                            }

                            coroutineScope.launch {
                                turnProgress.snapTo(rawProgress)
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    val duration = System.currentTimeMillis() - startTime

                    if (isDrag) {
                        val currentP = turnProgress.value
                        val shouldComplete = currentP >= 0.16f

                        coroutineScope.launch {
                            if (shouldComplete && targetIdx in 0 until totalSpreads) {
                                turnProgress.animateTo(1f, tween(320, easing = OrganicPageTurnEasing))
                                latestPagerState.scrollToPage(targetIdx)
                                latestOnPageTurned?.invoke(targetIdx)
                                PageSoundManager.playPageTurnSound(preferences.pageSoundType, preferences.soundEnabled)
                            } else {
                                turnProgress.animateTo(0f, tween(240, easing = OrganicPageTurnEasing))
                            }
                            activeCorner = null
                            targetSpreadIndex = -1
                            turnProgress.snapTo(0f)
                        }
                    } else if (duration < 350 && abs(totalDx) < 14f && abs(totalDy) < 14f) {
                        // Clean edge tap
                        val tapRatio = startPos.x / screenW

                        when {
                            // Left margin (< 18%) -> Animated corner curl backward
                            tapRatio < 0.18f -> {
                                if (activeCurrentIndex > 0) {
                                    activeCorner = if (isBottom) DragCorner.BOTTOM_LEFT else DragCorner.TOP_LEFT
                                    targetSpreadIndex = activeCurrentIndex - 1

                                    coroutineScope.launch {
                                        turnProgress.snapTo(0f)
                                        turnProgress.animateTo(1f, tween(360, easing = OrganicPageTurnEasing))
                                        latestPagerState.scrollToPage(activeCurrentIndex - 1)
                                        latestOnPageTurned?.invoke(activeCurrentIndex - 1)
                                        PageSoundManager.playPageTurnSound(preferences.pageSoundType, preferences.soundEnabled)
                                        activeCorner = null
                                        targetSpreadIndex = -1
                                        turnProgress.snapTo(0f)
                                    }
                                }
                            }
                            // Right margin (> 82%) -> Animated corner curl forward
                            tapRatio > 0.82f -> {
                                if (activeCurrentIndex < totalSpreads - 1) {
                                    activeCorner = if (isBottom) DragCorner.BOTTOM_RIGHT else DragCorner.TOP_RIGHT
                                    targetSpreadIndex = activeCurrentIndex + 1

                                    coroutineScope.launch {
                                        turnProgress.snapTo(0f)
                                        turnProgress.animateTo(1f, tween(360, easing = OrganicPageTurnEasing))
                                        latestPagerState.scrollToPage(activeCurrentIndex + 1)
                                        latestOnPageTurned?.invoke(activeCurrentIndex + 1)
                                        PageSoundManager.playPageTurnSound(preferences.pageSoundType, preferences.soundEnabled)
                                        activeCorner = null
                                        targetSpreadIndex = -1
                                        turnProgress.snapTo(0f)
                                    }
                                }
                            }
                            // Center -> Toggle HUD controls
                            else -> {
                                onToggleControls()
                            }
                        }
                    }
                }
                }
            }
    ) {
        val targetSpread = if (targetSpreadIndex in spreads.indices) spreads[targetSpreadIndex] else null
        val p = turnProgress.value
        val corner = activeCorner

        if (isCurling && targetSpread != null && corner != null && currentSpread != null) {
            val isBottomCorner = corner == DragCorner.BOTTOM_RIGHT || corner == DragCorner.BOTTOM_LEFT

            if (isDualPage && currentSpread.rightPage != null && targetSpread.rightPage != null) {
                // =========================================================================
                // DUAL-PAGE SPREAD (Landscape / Fold 8 Open)
                // In a real physical book, only the SINGLE LEAF being turned flips!
                // Forward: Right page of current spread flips across the central spine
                // to reveal the new right page underneath, while the left page remains stable.
                // =========================================================================
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val halfWidth = maxWidth / 2
                    val spineWidth = 24.dp
                    val eachPageWidth = halfWidth - (spineWidth / 2)

                    if (isTurningForward) {
                        // FORWARD TURN: Left page is stationary
                        Row(modifier = Modifier.fillMaxSize()) {
                            // Left Side: Shows current left page for p <= 0.5, then smoothly transitions to new left page
                            Box(modifier = Modifier.width(eachPageWidth).fillMaxHeight()) {
                                if (p < 0.5f) {
                                    BookSinglePageView(
                                        page = currentSpread.leftPage,
                                        preferences = preferences,
                                        isLeftPageInSpread = true,
                                        isBookmarked = isBookmarked(currentSpread.leftPage.pageNumber),
                                        onToggleBookmark = { onToggleBookmark(currentSpread.leftPage.pageNumber) },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    BookSinglePageView(
                                        page = targetSpread.leftPage,
                                        preferences = preferences,
                                        isLeftPageInSpread = true,
                                        isBookmarked = isBookmarked(targetSpread.leftPage.pageNumber),
                                        onToggleBookmark = { onToggleBookmark(targetSpread.leftPage.pageNumber) },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }

                            // Book Spine Gutter
                            BookSpineGutter(
                                theme = preferences.paperTheme,
                                modifier = Modifier.width(spineWidth).fillMaxHeight()
                            )

                            // Right Side: Underneath revealed page (target spread right page)
                            Box(modifier = Modifier.width(eachPageWidth).fillMaxHeight()) {
                                BookSinglePageView(
                                    page = targetSpread.rightPage!!,
                                    preferences = preferences,
                                    isLeftPageInSpread = false,
                                    isBookmarked = isBookmarked(targetSpread.rightPage!!.pageNumber),
                                    onToggleBookmark = { onToggleBookmark(targetSpread.rightPage!!.pageNumber) },
                                    modifier = Modifier.fillMaxSize()
                                )

                                // Soft ambient cast shadow from the curling page
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .drawWithContent {
                                            val shadowAlpha = (sin(p * PI.toFloat()) * 0.40f).coerceIn(0f, 0.40f)
                                            if (shadowAlpha > 0.01f) {
                                                drawRect(
                                                    brush = Brush.horizontalGradient(
                                                        colors = listOf(
                                                            Color.Black.copy(alpha = shadowAlpha),
                                                            Color.Black.copy(alpha = shadowAlpha * 0.4f),
                                                            Color.Transparent
                                                        )
                                                    )
                                                )
                                            }
                                        }
                                )
                            }
                        }

                        // FLIPPING LEAF: Positioned on the right page, anchored to its left edge (the center spine)
                        // Enhanced multi-axis physical corner curl
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .width(eachPageWidth)
                                .fillMaxHeight()
                                .graphicsLayer {
                                    cameraDistance = 24f * density
                                    transformOrigin = TransformOrigin(0f, if (isBottomCorner) 0.95f else 0.05f)
                                    // Deep 3D curl: rotationY + corner lift rotationZ + diagonal tilt rotationX
                                    rotationY = -180f * p
                                    rotationZ = (if (isBottomCorner) -1f else 1f) * 28f * sin(p * PI.toFloat())
                                    rotationX = (if (isBottomCorner) -1f else 1f) * 12f * sin(p * PI.toFloat())
                                    scaleX = 1f - (0.08f * sin(p * PI.toFloat()))
                                    scaleY = 1f - (0.04f * sin(p * PI.toFloat()))
                                    shadowElevation = 28.dp.toPx() * sin(p * PI.toFloat())
                                }
                                .background(preferences.paperTheme.backgroundColor)
                                .drawWithContent {
                                    drawContent()

                                    // Moving cylinder specular crest & reverse shade
                                    val curlIntensity = sin(p * PI.toFloat())
                                    if (curlIntensity > 0.01f) {
                                        val rollX = size.width * (1f - p)
                                        val bandW = 60.dp.toPx()

                                        drawRect(
                                            brush = Brush.horizontalGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    Color.Black.copy(alpha = 0.30f * curlIntensity),
                                                    Color.White.copy(alpha = 0.45f * curlIntensity),
                                                    Color.Black.copy(alpha = 0.40f * curlIntensity),
                                                    Color.Transparent
                                                ),
                                                startX = (rollX - bandW).coerceAtLeast(0f),
                                                endX = (rollX + bandW).coerceAtMost(size.width)
                                            )
                                        )

                                        if (p > 0.5f) {
                                            drawRect(color = Color.Black.copy(alpha = lerp(0.35f, 0.05f, (p - 0.5f) * 2f)))
                                        }
                                    }
                                }
                        ) {
                            if (p < 0.5f) {
                                BookSinglePageView(
                                    page = currentSpread.rightPage!!,
                                    preferences = preferences,
                                    isLeftPageInSpread = false,
                                    isBookmarked = isBookmarked(currentSpread.rightPage!!.pageNumber),
                                    onToggleBookmark = { onToggleBookmark(currentSpread.rightPage!!.pageNumber) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer { scaleX = -1f }
                                ) {
                                    BookSinglePageView(
                                        page = targetSpread.leftPage,
                                        preferences = preferences,
                                        isLeftPageInSpread = true,
                                        isBookmarked = isBookmarked(targetSpread.leftPage.pageNumber),
                                        onToggleBookmark = { onToggleBookmark(targetSpread.leftPage.pageNumber) },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        }
                    } else {
                        // BACKWARD TURN: Left leaf flips to the right
                        Row(modifier = Modifier.fillMaxSize()) {
                            // Left Side: Underneath revealed page (target spread left page)
                            Box(modifier = Modifier.width(eachPageWidth).fillMaxHeight()) {
                                BookSinglePageView(
                                    page = targetSpread.leftPage,
                                    preferences = preferences,
                                    isLeftPageInSpread = true,
                                    isBookmarked = isBookmarked(targetSpread.leftPage.pageNumber),
                                    onToggleBookmark = { onToggleBookmark(targetSpread.leftPage.pageNumber) },
                                    modifier = Modifier.fillMaxSize()
                                )

                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .drawWithContent {
                                            val shadowAlpha = (sin(p * PI.toFloat()) * 0.40f).coerceIn(0f, 0.40f)
                                            if (shadowAlpha > 0.01f) {
                                                drawRect(
                                                    brush = Brush.horizontalGradient(
                                                        colors = listOf(
                                                            Color.Transparent,
                                                            Color.Black.copy(alpha = shadowAlpha * 0.4f),
                                                            Color.Black.copy(alpha = shadowAlpha)
                                                        )
                                                    )
                                                )
                                            }
                                        }
                                )
                            }

                            // Book Spine Gutter
                            BookSpineGutter(
                                theme = preferences.paperTheme,
                                modifier = Modifier.width(spineWidth).fillMaxHeight()
                            )

                            // Right Side: Shows current right page until p > 0.5, then target right page
                            Box(modifier = Modifier.width(eachPageWidth).fillMaxHeight()) {
                                if (p < 0.5f) {
                                    BookSinglePageView(
                                        page = currentSpread.rightPage!!,
                                        preferences = preferences,
                                        isLeftPageInSpread = false,
                                        isBookmarked = isBookmarked(currentSpread.rightPage!!.pageNumber),
                                        onToggleBookmark = { onToggleBookmark(currentSpread.rightPage!!.pageNumber) },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    BookSinglePageView(
                                        page = targetSpread.rightPage!!,
                                        preferences = preferences,
                                        isLeftPageInSpread = false,
                                        isBookmarked = isBookmarked(targetSpread.rightPage!!.pageNumber),
                                        onToggleBookmark = { onToggleBookmark(targetSpread.rightPage!!.pageNumber) },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        }

                        // FLIPPING LEAF: Positioned on the left page, anchored to its right edge (the spine)
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .width(eachPageWidth)
                                .fillMaxHeight()
                                .graphicsLayer {
                                    cameraDistance = 24f * density
                                    transformOrigin = TransformOrigin(1f, if (isBottomCorner) 0.95f else 0.05f)
                                    rotationY = 180f * p
                                    rotationZ = (if (isBottomCorner) 1f else -1f) * 28f * sin(p * PI.toFloat())
                                    rotationX = (if (isBottomCorner) -1f else 1f) * 12f * sin(p * PI.toFloat())
                                    scaleX = 1f - (0.08f * sin(p * PI.toFloat()))
                                    scaleY = 1f - (0.04f * sin(p * PI.toFloat()))
                                    shadowElevation = 28.dp.toPx() * sin(p * PI.toFloat())
                                }
                                .background(preferences.paperTheme.backgroundColor)
                                .drawWithContent {
                                    drawContent()

                                    val curlIntensity = sin(p * PI.toFloat())
                                    if (curlIntensity > 0.01f) {
                                        val rollX = size.width * p
                                        val bandW = 60.dp.toPx()

                                        drawRect(
                                            brush = Brush.horizontalGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    Color.Black.copy(alpha = 0.40f * curlIntensity),
                                                    Color.White.copy(alpha = 0.45f * curlIntensity),
                                                    Color.Black.copy(alpha = 0.30f * curlIntensity),
                                                    Color.Transparent
                                                ),
                                                startX = (rollX - bandW).coerceAtLeast(0f),
                                                endX = (rollX + bandW).coerceAtMost(size.width)
                                            )
                                        )

                                        if (p > 0.5f) {
                                            drawRect(color = Color.Black.copy(alpha = lerp(0.35f, 0.05f, (p - 0.5f) * 2f)))
                                        }
                                    }
                                }
                        ) {
                            if (p < 0.5f) {
                                BookSinglePageView(
                                    page = currentSpread.leftPage,
                                    preferences = preferences,
                                    isLeftPageInSpread = true,
                                    isBookmarked = isBookmarked(currentSpread.leftPage.pageNumber),
                                    onToggleBookmark = { onToggleBookmark(currentSpread.leftPage.pageNumber) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer { scaleX = -1f }
                                ) {
                                    BookSinglePageView(
                                        page = targetSpread.rightPage!!,
                                        preferences = preferences,
                                        isLeftPageInSpread = false,
                                        isBookmarked = isBookmarked(targetSpread.rightPage!!.pageNumber),
                                        onToggleBookmark = { onToggleBookmark(targetSpread.rightPage!!.pageNumber) },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // =========================================================================
                // SINGLE-PAGE VIEW (Folded Phone / Portrait)
                // Enhanced 3D Corner Curl
                // =========================================================================
                Box(modifier = Modifier.fillMaxSize()) {
                    // LAYER 1: Underneath Target Page
                    BookSpreadView(
                        spread = targetSpread,
                        preferences = preferences,
                        isBookmarked = isBookmarked,
                        onToggleBookmark = onToggleBookmark,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Cast shadow from curling page
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .drawWithContent {
                                val underShadowAlpha = (sin(p * PI.toFloat()) * 0.45f).coerceIn(0f, 0.45f)
                                if (underShadowAlpha > 0.01f) {
                                    drawRect(
                                        brush = Brush.horizontalGradient(
                                            colors = listOf(
                                                Color.Black.copy(alpha = underShadowAlpha * 0.7f),
                                                Color.Black.copy(alpha = underShadowAlpha),
                                                Color.Transparent
                                            ),
                                            startX = if (isTurningForward) 0f else size.width,
                                            endX = if (isTurningForward) size.width else 0f
                                        )
                                    )
                                }
                            }
                    )

                    // LAYER 2: 3D Corner-Curling Current Sheet
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                cameraDistance = 24f * density
                                transformOrigin = TransformOrigin(
                                    if (isTurningForward) 0f else 1f,
                                    if (isBottomCorner) 0.95f else 0.05f
                                )
                                rotationY = (if (isTurningForward) -180f else 180f) * p
                                rotationZ = (if (isBottomCorner) (if (isTurningForward) -1f else 1f) else (if (isTurningForward) 1f else -1f)) * 30f * sin(p * PI.toFloat())
                                rotationX = (if (isBottomCorner) -1f else 1f) * 14f * sin(p * PI.toFloat())
                                scaleX = 1f - (0.09f * sin(p * PI.toFloat()))
                                scaleY = 1f - (0.04f * sin(p * PI.toFloat()))
                                shadowElevation = 32.dp.toPx() * sin(p * PI.toFloat())
                            }
                            .drawWithContent {
                                drawContent()

                                val curlIntensity = sin(p * PI.toFloat())
                                if (curlIntensity > 0.01f) {
                                    val rollX = if (isTurningForward) size.width * (1f - p) else size.width * p
                                    val bandW = 70.dp.toPx()

                                    drawRect(
                                        brush = Brush.horizontalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color.Black.copy(alpha = 0.35f * curlIntensity),
                                                Color.White.copy(alpha = 0.45f * curlIntensity),
                                                Color.Black.copy(alpha = 0.40f * curlIntensity),
                                                Color.Transparent
                                            ),
                                            startX = (rollX - bandW).coerceAtLeast(0f),
                                            endX = (rollX + bandW).coerceAtMost(size.width)
                                        )
                                    )

                                    if (p > 0.5f) {
                                        drawRect(color = Color.Black.copy(alpha = lerp(0.35f, 0.05f, (p - 0.5f) * 2f)))
                                    }
                                }
                            }
                    ) {
                        BookSpreadView(
                            spread = currentSpread,
                            preferences = preferences,
                            isBookmarked = isBookmarked,
                            onToggleBookmark = onToggleBookmark,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        } else {
            // REST / NORMAL DISPLAY (No active curl in progress)
            if (currentSpread != null) {
                BookSpreadView(
                    spread = currentSpread,
                    preferences = preferences,
                    isBookmarked = isBookmarked,
                    onToggleBookmark = onToggleBookmark,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
