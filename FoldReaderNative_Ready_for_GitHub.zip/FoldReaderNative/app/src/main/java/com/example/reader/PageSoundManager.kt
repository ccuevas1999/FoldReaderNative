package com.example.reader

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.PageSoundType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Random
import kotlin.math.exp
import kotlin.math.sin

object PageSoundManager {

    private const val SAMPLE_RATE = 44100

    // Pre-synthesized PCM buffers for each physical sound type
    private val pcmCache: Map<PageSoundType, ShortArray> by lazy {
        mapOf(
            PageSoundType.MAGAZINE_GLOSS to generateMagazineGloss(),
            PageSoundType.NEWSPAPER_RUSTLE to generateNewspaperRustle(),
            PageSoundType.HEAVY_PARCHMENT to generateHeavyParchment(),
            PageSoundType.PAPERBACK_FLICK to generatePaperbackFlick()
        )
    }

    private val audioTrackMap = mutableMapOf<PageSoundType, AudioTrack>()

    init {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                for ((type, pcm) in pcmCache) {
                    val track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(SAMPLE_RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(pcm.size * 2)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build()

                    track.write(pcm, 0, pcm.size)
                    audioTrackMap[type] = track
                }
            } catch (e: Exception) {
                // Audio initialization fallback
            }
        }
    }

    /**
     * 1. Glossy Magazine Flip: Crisp, smooth coated paper slide with bright high-frequency friction
     * like turning a page in Vogue, Time, or National Geographic.
     */
    private fun generateMagazineGloss(): ShortArray {
        val numSamples = (SAMPLE_RATE * 0.14).toInt()
        val samples = ShortArray(numSamples)
        val random = Random(441)
        var b1 = 0.0
        var b2 = 0.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val white = random.nextDouble() * 2.0 - 1.0

            // High-mid bandpass filter (2400Hz - 4200Hz) for slick, glossy paper friction
            b1 += 0.38 * (white - b1)
            b2 += 0.32 * (b1 - b2)

            // Glossy paper sliding envelope: quick 8ms lift, smooth 110ms coated-paper slide
            val envelope = when {
                t < 0.008 -> (t / 0.008)
                else -> exp(-(t - 0.008) * 30.0)
            }

            val value = (b2 * envelope * 0.85).coerceIn(-1.0, 1.0)
            samples[i] = (value * Short.MAX_VALUE).toInt().toShort()
        }
        return samples
    }

    /**
     * 2. Newspaper Broadsheet: Fibrous, dry newsprint with randomized micro-crinkles
     * and broad fluttering friction like turning a broadsheet newspaper page.
     */
    private fun generateNewspaperRustle(): ShortArray {
        val numSamples = (SAMPLE_RATE * 0.22).toInt()
        val samples = ShortArray(numSamples)
        val random = Random(882)
        var lp = 0.0
        val alpha = 0.16 // Warm newsprint fiber body

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val white = random.nextDouble() * 2.0 - 1.0
            lp += alpha * (white - lp)

            // Micro-crinkles: tiny random fiber snap impulses characteristic of dry newsprint
            val isCrinkle = (random.nextDouble() < 0.035) && (t in 0.02..0.14)
            val crinkleBurst = if (isCrinkle) (random.nextDouble() * 2.0 - 1.0) * 0.55 else 0.0

            // Broadsheet fluttering envelope: longer 200ms airy paper drag
            val envelope = when {
                t < 0.025 -> (t / 0.025)
                else -> exp(-(t - 0.025) * 14.0)
            }

            val value = ((lp * 0.70 + crinkleBurst) * envelope * 0.75).coerceIn(-1.0, 1.0)
            samples[i] = (value * Short.MAX_VALUE).toInt().toShort()
        }
        return samples
    }

    /**
     * 3. Heavy Book Parchment: Rich, warm cotton paper drag with low air displacement
     * like turning a thick page in a hardcover novel.
     */
    private fun generateHeavyParchment(): ShortArray {
        val numSamples = (SAMPLE_RATE * 0.18).toInt()
        val samples = ShortArray(numSamples)
        val random = Random(123)
        var last = 0.0
        val alpha = 0.09 // Deep cotton fiber low-pass

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val white = random.nextDouble() * 2.0 - 1.0
            last += alpha * (white - last)

            // Low frequency air displacement of thick heavy page (110Hz)
            val airSwoosh = sin(2.0 * Math.PI * 110.0 * t) * 0.16

            val envelope = when {
                t < 0.018 -> (t / 0.018)
                else -> exp(-(t - 0.018) * 18.0)
            }

            val value = ((last * 0.85 + airSwoosh) * envelope * 0.75).coerceIn(-1.0, 1.0)
            samples[i] = (value * Short.MAX_VALUE).toInt().toShort()
        }
        return samples
    }

    /**
     * 4. Paperback Leaf Flick: Snappy thumb flick on corner and quick leaf release.
     */
    private fun generatePaperbackFlick(): ShortArray {
        val numSamples = (SAMPLE_RATE * 0.12).toInt()
        val samples = ShortArray(numSamples)
        val random = Random(333)
        var noise = 0.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val white = random.nextDouble() * 2.0 - 1.0
            noise += 0.24 * (white - noise)

            // Initial corner flick pop
            val flickPop = if (t < 0.005) sin(2.0 * Math.PI * 1600.0 * t) * 0.70 else 0.0

            val flutter = when {
                t < 0.012 -> (t / 0.012)
                else -> exp(-(t - 0.012) * 34.0)
            }

            val value = ((noise * flutter * 0.50) + flickPop).coerceIn(-1.0, 1.0)
            samples[i] = (value * Short.MAX_VALUE).toInt().toShort()
        }
        return samples
    }

    fun playPageTurnSound(soundType: PageSoundType, enabled: Boolean) {
        if (!enabled || soundType == PageSoundType.NONE) return

        CoroutineScope(Dispatchers.Default).launch {
            try {
                val track = audioTrackMap[soundType]
                if (track != null && track.state == AudioTrack.STATE_INITIALIZED) {
                    track.stop()
                    track.reloadStaticData()
                    track.play()
                }
            } catch (e: Exception) {
                // Ignore audio play errors
            }
        }
    }

    fun previewSound(soundType: PageSoundType) {
        if (soundType == PageSoundType.NONE) return
        playPageTurnSound(soundType, enabled = true)
    }
}
