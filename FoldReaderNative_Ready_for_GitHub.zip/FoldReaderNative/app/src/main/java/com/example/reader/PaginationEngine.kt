package com.example.reader

import com.example.model.*

object PaginationEngine {

    /**
     * Splits a BookContent into individual BookPages based on content flow,
     * chapter beginnings, font size, and reader preferences.
     */
    fun paginate(
        content: BookContent,
        preferences: ReaderPreferences,
        isDualPage: Boolean
    ): List<BookPage> {
        val pages = mutableListOf<BookPage>()

        // Page budget in rough weight units
        // Larger font size reduces page budget; dual page gives more breathing room
        val baseBudget = if (isDualPage) 750 else 600
        val fontFactor = (16f / preferences.fontSizeSp.coerceIn(12, 28)) * (1.45f / preferences.lineSpacingMultiplier)
        val pageCapacity = (baseBudget * fontFactor).toInt().coerceAtLeast(350)

        // Generate Cover Page as Page 1
        pages.add(
            BookPage(
                pageNumber = 1,
                totalPages = 1, // updated at end
                runningHeader = content.title,
                elements = listOf(
                    BookElement.ChapterTitle(
                        title = content.title,
                        subtitle = content.author ?: "Google Docs Edition"
                    )
                ),
                isCover = true,
                isChapterStart = true
            )
        )

        var currentElements = mutableListOf<BookElement>()
        var currentWeight = 0
        var currentChapter = content.title
        var pageNum = 2

        fun flushPage(isChapterStart: Boolean = false) {
            if (currentElements.isNotEmpty()) {
                pages.add(
                    BookPage(
                        pageNumber = pageNum++,
                        totalPages = 1,
                        runningHeader = currentChapter,
                        elements = currentElements.toList(),
                        isCover = false,
                        isChapterStart = isChapterStart
                    )
                )
                currentElements = mutableListOf()
                currentWeight = 0
            }
        }

        for (element in content.elements) {
            when (element) {
                is BookElement.ChapterTitle -> {
                    // Chapters always start on a fresh page
                    flushPage()
                    currentChapter = element.title
                    currentElements.add(element)
                    currentWeight += 200
                }
                is BookElement.Heading -> {
                    val headingWeight = 120
                    if (currentWeight + headingWeight > pageCapacity && currentElements.isNotEmpty()) {
                        flushPage()
                    }
                    currentElements.add(element)
                    currentWeight += headingWeight
                }
                is BookElement.Paragraph -> {
                    val words = element.text.split("\\s+".toRegex()).filter { it.isNotBlank() }
                    val paraWeight = (words.size * 5)

                    if (currentWeight + paraWeight <= pageCapacity) {
                        currentElements.add(element)
                        currentWeight += paraWeight
                    } else {
                        // Check if paragraph fits if we start a new page
                        if (currentElements.isNotEmpty()) {
                            flushPage()
                        }

                        if (paraWeight <= pageCapacity) {
                            currentElements.add(element)
                            currentWeight += paraWeight
                        } else {
                            // Split very long paragraph across pages gracefully
                            var wordOffset = 0
                            val wordsPerPage = (pageCapacity / 5).coerceAtLeast(40)
                            var isFirstChunk = element.isFirstOfChapter

                            while (wordOffset < words.size) {
                                val chunkWords = words.subList(
                                    wordOffset,
                                    (wordOffset + wordsPerPage).coerceAtMost(words.size)
                                )
                                val chunkText = chunkWords.joinToString(" ")
                                currentElements.add(
                                    BookElement.Paragraph(
                                        text = chunkText,
                                        isFirstOfChapter = isFirstChunk
                                    )
                                )
                                wordOffset += chunkWords.size
                                isFirstChunk = false

                                if (wordOffset < words.size) {
                                    flushPage()
                                } else {
                                    currentWeight = (chunkWords.size * 5)
                                }
                            }
                        }
                    }
                }
                is BookElement.Blockquote -> {
                    val quoteWeight = (element.quote.length / 2).coerceAtLeast(100)
                    if (currentWeight + quoteWeight > pageCapacity && currentElements.isNotEmpty()) {
                        flushPage()
                    }
                    currentElements.add(element)
                    currentWeight += quoteWeight
                }
                is BookElement.BulletList -> {
                    val listWeight = element.items.size * 60
                    if (currentWeight + listWeight > pageCapacity && currentElements.isNotEmpty()) {
                        flushPage()
                    }
                    currentElements.add(element)
                    currentWeight += listWeight
                }
                is BookElement.Divider -> {
                    currentElements.add(element)
                    currentWeight += 50
                    if (currentWeight > pageCapacity * 0.85) {
                        flushPage()
                    }
                }
            }
        }
        flushPage()

        // Update totalPages on all pages
        val total = pages.size
        val finalizedPages = pages.map { it.copy(totalPages = total) }

        // Update TocEntry page numbers based on element placement
        for (toc in content.tableOfContents) {
            // Find which page contains this TOC title
            val matchingPage = finalizedPages.find { page ->
                page.elements.any { elem ->
                    when (elem) {
                        is BookElement.ChapterTitle -> elem.title.equals(toc.title, ignoreCase = true)
                        is BookElement.Heading -> elem.text.equals(toc.title, ignoreCase = true)
                        else -> false
                    }
                }
            }
            if (matchingPage != null) {
                toc.pageNumber = matchingPage.pageNumber
            }
        }

        return finalizedPages
    }

    /**
     * Groups pages into Spreads:
     * - In Dual-Page mode: Left Page + Right Page per spread
     * - In Single-Page mode: 1 Page per spread
     */
    fun createSpreads(pages: List<BookPage>, isDualPage: Boolean): List<BookSpread> {
        if (pages.isEmpty()) return emptyList()

        if (!isDualPage) {
            return pages.mapIndexed { index, page ->
                BookSpread(
                    spreadIndex = index,
                    leftPage = page,
                    rightPage = null,
                    isDualPage = false
                )
            }
        }

        // Two-page book spreads
        val spreads = mutableListOf<BookSpread>()
        var spreadIdx = 0
        var i = 0

        while (i < pages.size) {
            val left = pages[i]
            val right = if (i + 1 < pages.size) pages[i + 1] else null
            spreads.add(
                BookSpread(
                    spreadIndex = spreadIdx++,
                    leftPage = left,
                    rightPage = right,
                    isDualPage = true
                )
            )
            i += 2
        }

        return spreads
    }
}
