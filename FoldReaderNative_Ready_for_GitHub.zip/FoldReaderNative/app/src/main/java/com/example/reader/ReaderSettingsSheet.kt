package com.example.reader

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.*

/** Simple reader options: no nonworking font resize, no cream/sepia, AMOLED app chrome. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderSettingsSheet(
    preferences: ReaderPreferences,
    onUpdatePreferences: (ReaderPreferences) -> Unit,
    onOpenSearch: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp).padding(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Reader settings", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close settings") }
            }

            Text("Page background", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(PaperTheme.LINEN_WHITE, PaperTheme.MIDNIGHT_LEATHER).forEach { paper ->
                    FilterChip(
                        selected = preferences.paperTheme == paper,
                        onClick = { onUpdatePreferences(preferences.copy(paperTheme = paper)) },
                        label = { Text(if (paper.isDark) "Dark" else "White") }
                    )
                }
            }

            HorizontalDivider()
            Text("Page turning", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PageAnimationType.entries.forEach { animation ->
                    FilterChip(
                        selected = preferences.pageAnimationType == animation,
                        onClick = { onUpdatePreferences(preferences.copy(pageAnimationType = animation)) },
                        label = { Text(animation.displayName) }
                    )
                }
            }

            HorizontalDivider()
            Text("Foldable layout", style = MaterialTheme.typography.titleMedium)
            Text("Portrait displays one page. Unfolded landscape displays two pages.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(FoldDisplayMode.AUTO_FOLD_DETECT, FoldDisplayMode.FORCE_SINGLE_PAGE).forEach { mode ->
                    FilterChip(
                        selected = preferences.foldDisplayMode == mode,
                        onClick = { onUpdatePreferences(preferences.copy(foldDisplayMode = mode)) },
                        label = { Text(if (mode == FoldDisplayMode.AUTO_FOLD_DETECT) "Automatic" else "Single") }
                    )
                }
            }

            HorizontalDivider()
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Page-turn sound", style = MaterialTheme.typography.titleMedium)
                    Text("Synthetic paper rustle", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = preferences.soundEnabled,
                    onCheckedChange = { onUpdatePreferences(preferences.copy(soundEnabled = it)) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PageSoundType.entries.forEach { sound ->
                    if (sound in listOf(PageSoundType.NONE, PageSoundType.MAGAZINE_GLOSS, PageSoundType.PAPERBACK_FLICK)) {
                        FilterChip(
                            selected = preferences.pageSoundType == sound,
                            onClick = { onUpdatePreferences(preferences.copy(pageSoundType = sound)) },
                            label = { Text(when(sound) { PageSoundType.NONE -> "Silent"; PageSoundType.MAGAZINE_GLOSS -> "Soft"; else -> "Crisp" }) }
                        )
                    }
                }
            }
            HorizontalDivider()
            OutlinedButton(onClick = { onDismiss(); onOpenSearch() }, modifier = Modifier.fillMaxWidth()) {
                Text("Search this document")
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
