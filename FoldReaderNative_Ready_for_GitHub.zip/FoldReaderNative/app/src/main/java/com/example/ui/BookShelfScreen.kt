package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BookContent
import com.example.model.BookCoverConfig
import com.example.model.DocSource
import com.example.ui.theme.BookGold
import com.example.ui.theme.PaperCream
import com.example.ui.theme.PlayfairFontFamily

import com.example.model.UiThemeMode
import androidx.compose.foundation.BorderStroke

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookShelfScreen(
    recentDocs: List<DocSource>,
    sampleDocs: List<BookContent>,
    isLoading: Boolean,
    isOfflineOnly: Boolean,
    errorMessage: String?,
    uiThemeMode: UiThemeMode = UiThemeMode.AMOLED_NIGHT,
    onCycleUiThemeMode: () -> Unit = {},
    onOpenUrl: (String, BookCoverConfig?) -> Unit,
    onOpenSample: (BookContent) -> Unit,
    onOpenRecent: (DocSource) -> Unit,
    onEditCover: (DocSource) -> Unit,
    onRemoveBook: (String) -> Unit,
    onToggleOfflineMode: () -> Unit,
    onClearError: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDocDialog by remember { mutableStateOf(false) }

    val isDay = uiThemeMode == UiThemeMode.LIQUID_GLASS_DAY
    val primaryTextColor = if (isDay) Color(0xFF0F172A) else Color(0xFFEDEDED)
    val secondaryTextColor = if (isDay) Color(0xFF475569) else Color(0xFFA0A0A0)

    Scaffold(
        containerColor = if (isDay) Color(0xFFF1F5F9) else Color.Black,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.MenuBook,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "DocuBook Library",
                                fontFamily = PlayfairFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = primaryTextColor,
                                fontSize = 21.sp
                            )
                            Text(
                                text = if (isOfflineOnly) "Offline Shelf Mode Active" else "Live Docs • Dual Page on Fold 8",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isOfflineOnly) Color(0xFFE6A23C) else secondaryTextColor
                            )
                        }
                    }
                },
                actions = {
                    // Offline Mode switch chip
                    FilterChip(
                        selected = isOfflineOnly,
                        onClick = onToggleOfflineMode,
                        label = {
                            Text(
                                text = if (isOfflineOnly) "Offline" else "Online",
                                fontSize = 11.sp,
                                color = primaryTextColor
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = if (isOfflineOnly) Icons.Default.CloudOff else Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = primaryTextColor,
                                modifier = Modifier.size(14.dp)
                            )
                        },
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .testTag("toggle_offline_mode_chip")
                    )

                    IconButton(
                        onClick = { showAddDocDialog = true },
                        modifier = Modifier.testTag("add_doc_appbar_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Google Doc to Shelf",
                            tint = primaryTextColor
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (isDay) Color(0xEBFFFFFF) else Color.Black
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDocDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add Google Doc", fontWeight = FontWeight.Bold) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_google_doc")
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Error alert banner if any
            if (!errorMessage.isNullOrBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onClearError, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Bookshelf Grid displaying books on physical-style shelves
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 118.dp),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Shelf Header
                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                    ShelfHeroHeader(
                        totalBooks = recentDocs.size + sampleDocs.size,
                        isDay = isDay,
                        onAddDoc = { showAddDocDialog = true }
                    )
                }

                // Recent User Google Docs on Shelf
                if (recentDocs.isNotEmpty()) {
                    item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                        Text(
                            text = "Your Google Docs on Shelf",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = primaryTextColor,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                    }

                    items(recentDocs, key = { it.id }) { doc ->
                        BookShelfItem(
                            doc = doc,
                            uiThemeMode = uiThemeMode,
                            onClick = { onOpenRecent(doc) },
                            onEditCover = { onEditCover(doc) },
                            onRemove = { onRemoveBook(doc.id) }
                        )
                    }
                }

                // Sample Manuscripts on Shelf
                item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                    Text(
                        text = "Curated Manuscripts",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = primaryTextColor,
                        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                    )
                }

                items(sampleDocs, key = { it.docId }) { sample ->
                    SampleShelfItem(
                        sample = sample,
                        uiThemeMode = uiThemeMode,
                        onClick = { onOpenSample(sample) }
                    )
                }
            }
        }
    }

    // Add Google Doc to Shelf Dialog
    if (showAddDocDialog) {
        AddGoogleDocDialog(
            isLoading = isLoading,
            onAdd = { url, coverConfig ->
                onOpenUrl(url, coverConfig)
                showAddDocDialog = false
            },
            onDismiss = { showAddDocDialog = false }
        )
    }
}

@Composable
fun ShelfHeroHeader(
    totalBooks: Int,
    isDay: Boolean = true,
    onAddDoc: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDay) Color(0xD8FFFFFF) else Color(0xFF161616)
        ),
        border = BorderStroke(
            1.dp,
            if (isDay) Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0x7094A3B8)))
            else Brush.verticalGradient(listOf(Color(0x30FFFFFF), Color(0x10FFFFFF)))
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Bookshelf ($totalBooks volumes)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isDay) Color(0xFF0F172A) else Color(0xFFEDEDED)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Live synced with Google Docs • Custom foil stamped covers • Two facing pages on Fold 8",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isDay) Color(0xFF475569) else Color(0xFF94A3B8)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
                onClick = onAddDoc,
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.AddLink, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Doc")
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun BookShelfItem(
    doc: DocSource,
    uiThemeMode: UiThemeMode = UiThemeMode.AMOLED_NIGHT,
    onClick: () -> Unit,
    onEditCover: () -> Unit,
    onRemove: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    var showRemoveDialog by remember { mutableStateOf(false) }

    if (showRemoveDialog) {
        AlertDialog(
            onDismissRequest = { showRemoveDialog = false },
            icon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Remove from Shelf") },
            text = { Text("Remove \"${doc.coverConfig.customTitle ?: doc.title}\" from your bookshelf?") },
            confirmButton = {
                Button(
                    onClick = {
                        showRemoveDialog = false
                        onRemove()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Remove")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shelf_book_${doc.id}")
    ) {
        // Physical Hardcover Book with 1-Tap Open and Long-Press to Remove
        Box(
            modifier = Modifier
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = { showRemoveDialog = true }
                )
        ) {
            BookCoverView(
                coverConfig = doc.coverConfig,
                defaultTitle = doc.title,
                width = 108.dp,
                height = 156.dp,
                readingProgress = doc.readingProgressPercent
            )

            // Edit cover quick button on top right of book
            IconButton(
                onClick = { menuExpanded = true },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(28.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Customize Book Cover") },
                    leadingIcon = { Icon(Icons.Default.Palette, contentDescription = null) },
                    onClick = {
                        menuExpanded = false
                        onEditCover()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Open Book") },
                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null) },
                    onClick = {
                        menuExpanded = false
                        onClick()
                    }
                )
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Text("Remove from Shelf", color = MaterialTheme.colorScheme.error) },
                    leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                    onClick = {
                        menuExpanded = false
                        showRemoveDialog = true
                    }
                )
            }
        }

        // Shelf Plank: Liquid Glass (Day) or Obsidian (AMOLED Night)
        val isDayShelf = uiThemeMode == UiThemeMode.LIQUID_GLASS_DAY
        val shelfColors = if (isDayShelf) {
            listOf(Color(0xE0FFFFFF), Color(0x90CBD5E1), Color(0x7094A3B8))
        } else {
            listOf(Color(0xFF2A2A2A), Color(0xFF0C0C0C))
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .padding(horizontal = 4.dp)
                .background(
                    Brush.verticalGradient(colors = shelfColors),
                    RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp)
                )
                .border(
                    width = if (isDayShelf) 1.dp else 0.dp,
                    brush = Brush.horizontalGradient(listOf(Color(0xE0FFFFFF), Color(0x7094A3B8), Color(0xE0FFFFFF))),
                    shape = RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp)
                )
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Title & metadata below shelf: dark slate in Day, light in Night
        Text(
            text = doc.coverConfig.customTitle ?: doc.title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = if (isDayShelf) Color(0xFF0F172A) else Color(0xFFEDEDED),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (doc.readingProgressPercent > 0f) {
                Text(
                    text = "${(doc.readingProgressPercent * 100).toInt()}% read",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "•",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isDayShelf) Color(0xFF64748B) else Color(0xFF94A3B8)
                )
            }
            if (doc.isOfflineCached) {
                Text(
                    text = "Offline ready",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF10B981)
                )
            }
        }
    }
}

@Composable
fun SampleShelfItem(
    sample: BookContent,
    uiThemeMode: UiThemeMode = UiThemeMode.AMOLED_NIGHT,
    onClick: () -> Unit
) {
    val sampleCover = remember(sample.docId) {
        when (sample.docId) {
            "sample_odyssey_orion" -> BookCoverConfig(
                coverColorHex = "#162238",
                motif = com.example.model.CoverMotif.CONSTELLATION,
                foilColor = com.example.model.FoilColor.GOLD,
                customTitle = sample.title,
                customAuthor = sample.author ?: "Sci-Fi Codex"
            )
            "sample_philosophy" -> BookCoverConfig(
                coverColorHex = "#3D1A24",
                motif = com.example.model.CoverMotif.OWL,
                foilColor = com.example.model.FoilColor.SILVER,
                customTitle = sample.title,
                customAuthor = sample.author ?: "Essay"
            )
            else -> BookCoverConfig(
                coverColorHex = "#142F22",
                motif = com.example.model.CoverMotif.BOOK,
                foilColor = com.example.model.FoilColor.BRONZE,
                customTitle = sample.title,
                customAuthor = sample.author ?: "Spec"
            )
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shelf_sample_${sample.docId}")
    ) {
        Box(modifier = Modifier.clickable(onClick = onClick)) {
            BookCoverView(
                coverConfig = sampleCover,
                defaultTitle = sample.title,
                width = 108.dp,
                height = 156.dp
            )
        }

        // Shelf Plank: Liquid Glass (Day) or Obsidian (Night)
        val isDayShelf = uiThemeMode == UiThemeMode.LIQUID_GLASS_DAY
        val shelfColors = if (isDayShelf) {
            listOf(Color(0xE0FFFFFF), Color(0x90CBD5E1), Color(0x7094A3B8))
        } else {
            listOf(Color(0xFF2A2A2A), Color(0xFF0C0C0C))
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .padding(horizontal = 4.dp)
                .background(
                    Brush.verticalGradient(colors = shelfColors),
                    RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp)
                )
                .border(
                    width = if (isDayShelf) 1.dp else 0.dp,
                    brush = Brush.horizontalGradient(listOf(Color(0xE0FFFFFF), Color(0x7094A3B8), Color(0xE0FFFFFF))),
                    shape = RoundedCornerShape(bottomStart = 2.dp, bottomEnd = 2.dp)
                )
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = sample.title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = if (isDayShelf) Color(0xFF0F172A) else Color(0xFFEDEDED),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Text(
            text = "Curated Manuscript",
            style = MaterialTheme.typography.labelSmall,
            color = if (isDayShelf) Color(0xFF64748B) else Color(0xFF94A3B8)
        )
    }
}

@Composable
fun AddGoogleDocDialog(
    isLoading: Boolean,
    onAdd: (String, BookCoverConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var urlInput by remember { mutableStateOf("") }
    var titleInput by remember { mutableStateOf("") }
    var selectedColorHex by remember { mutableStateOf("#3D1A24") }
    var selectedMotif by remember { mutableStateOf(com.example.model.CoverMotif.BOOK) }
    var selectedFoil by remember { mutableStateOf(com.example.model.FoilColor.GOLD) }
    val clipboardManager = LocalClipboardManager.current

    val currentCoverConfig = BookCoverConfig(
        coverColorHex = selectedColorHex,
        motif = selectedMotif,
        foilColor = selectedFoil,
        customTitle = titleInput.takeIf { it.isNotBlank() }
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AddCircleOutline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add Google Doc to Shelf")
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Mini 3D Book Preview
                BookCoverView(
                    coverConfig = currentCoverConfig,
                    defaultTitle = if (titleInput.isNotBlank()) titleInput else "New Book",
                    width = 110.dp,
                    height = 150.dp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Google Doc URL
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    label = { Text("Google Docs URL") },
                    placeholder = { Text("https://docs.google.com/document/d/...") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = {
                            val clip = clipboardManager.getText()?.text
                            if (!clip.isNullOrBlank()) urlInput = clip
                        }) {
                            Icon(Icons.Default.ContentPaste, contentDescription = "Paste")
                        }
                    },
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Custom Title (optional)
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = { titleInput = it },
                    label = { Text("Custom Title (Optional)") },
                    placeholder = { Text("Leave blank to auto-extract from Doc") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Color choices
                Text(
                    text = "COVER COLOR",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for ((name, hex) in COVER_COLOR_PALETTES) {
                        val color = Color(android.graphics.Color.parseColor(hex))
                        val isSelected = selectedColorHex.equals(hex, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 2.5.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.5f),
                                    shape = CircleShape
                                )
                                .clickable { selectedColorHex = hex },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Motif choices
                Text(
                    text = "EMBOSSED MOTIF",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (motif in com.example.model.CoverMotif.values().take(4)) {
                        FilterChip(
                            selected = selectedMotif == motif,
                            onClick = { selectedMotif = motif },
                            label = { Text(motif.symbol + " " + motif.displayName.split(" ").first(), fontSize = 10.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (urlInput.isNotBlank()) {
                        onAdd(urlInput.trim(), currentCoverConfig)
                    }
                },
                enabled = urlInput.isNotBlank() && !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Fetching...")
                } else {
                    Text("Add & Open in Book")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
