package com.example

import com.example.model.BookContent
import com.example.model.BookElement
import com.example.model.ReaderPreferences
import com.example.parser.GoogleDocsService
import com.example.reader.PaginationEngine
import org.junit.Assert.*
import org.junit.Test

class ReaderCoreTest {
    @Test fun acceptsSharedGoogleDocsLink() {
        val id = "1abcdefghijABCDEFGHIJklmnopqrstuv"
        assertEquals(id, GoogleDocsService.extractDocId("https://docs.google.com/document/d/$id/edit?usp=sharing"))
    }

    @Test fun spreadsHaveOnePageOrTwoPages() {
        val book = BookContent(
            docId = "test", title = "Demo", elements = List(20) {
                BookElement.Paragraph("The quick brown fox jumps over the lazy dog. ".repeat(6))
            }
        )
        val pages = PaginationEngine.paginate(book, ReaderPreferences(), isDualPage = false)
        assertTrue(pages.size > 1)
        val portrait = PaginationEngine.createSpreads(pages, isDualPage = false)
        assertTrue(portrait.all { it.rightPage == null })
        val landscape = PaginationEngine.createSpreads(pages, isDualPage = true)
        assertTrue(landscape.any { it.rightPage != null })
    }
}
