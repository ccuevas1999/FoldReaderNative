# Fold Reader Native (Android Studio / phone build)

This is a native Android project based on your DocFlip Kotlin application, with an AMOLED reader and no AppCreator24 outer toolbar. The book pages are drawn using **Jetpack Compose**, not the AppCreator24 web-page wrapper. This is an editable beta source project, **not yet a tested APK**.

## Features included

- Native immersive reading: hide Android status/navigation bars; tap the page center to reveal the reader's own controls
- Library with compact book covers, editable titles, decorative colors, and photos chosen from the phone
- Load *Google Docs with access enabled via the link* using the existing DocFlip native OkHttp importer. HTML export is attempted first, then plain text. Google login-only documents and documents with downloads disabled may not import.
- **Edit in Google Docs** uses Android's URL resolver. Refresh to retrieve changes
- A built-in sample book, chapter table of contents with Close button / outside-tap / Android Back, and full-text search
- Single page in portrait (folded or tall unfolded), two facing pages in landscape when wide enough
- Finger-based left/right page turning, plus Instant fallback; optional synthesized paper sound
- White/dark page backgrounds, with AMOLED-black app chrome, no cream/sepia, and no font resize controls
- Per-book reading progress and offline copy saved in the app's private files. Native import retains headings and paragraphs, but **does not perfectly reproduce all Google Docs formatting**.

## Requirements

Android 8+; intended for Galaxy Z Fold8. An internet connection is needed to import or refresh shared Google Docs.

## Build with Android Studio

Open this directory as a Gradle project. Use JDK 17 and Android SDK 35. Build the `debug` variant with `gradle :app:testDebugUnitTest :app:assembleDebug` (or **Build APK(s)** in Android Studio). The app id is `com.foldreader.nativebook`; it is **separate** from the existing AppCreator24 app, so installing it does not replace that app.

## Build on your phone using GitHub Actions

**Option A: native source uploaded as actual repository files.** Create a GitHub repository containing this folder's files. Go to **Actions → Build Fold Reader APK → Run workflow**. Once green, open the latest workflow run and download the `FoldReader-Native-APK` artifact.

**Option B: easiest when you only have the ZIP on your phone.**

1. Create a GitHub repository.
2. Upload `FoldReaderNative.zip` to the **root** of that repository using GitHub's web interface.
3. Create a new file `.github/workflows/build.yml` in the repository. Paste the included **`GitHub_Build_From_Phone.yml`** file contents into it, then commit.
4. Open GitHub **Actions → Build APK from uploaded ZIP → Run workflow** (or open the latest automatic run). Download `FoldReader-Native-APK` from the completed run's **Artifacts** section.
5. Extract the downloaded artifact ZIP on Android and open `app-debug.apk` to install it. You may need to allow installation from that browser/file manager.

The Actions job downloads Android SDK 35 and Gradle 8.11.1 on GitHub's computer. No Android Studio or SDK is required on your phone.

## Privacy and limitations

Your document contents and reading progress are stored locally on your phone (not intentionally uploaded to any app-specific server). When importing, the app requests Google's document-export endpoint. Only paste links you are authorized to read. Link-accessible documents may expose their contents to anyone with that link. The native beta does **not** include Google OAuth for restricted documents. There is no encryption at rest beyond Android's default app sandbox.

**Build status:** The cloud workflow is included but has not been run here. I cannot verify the native APK compiles or behaves correctly until the workflow is run in an Android build environment. The existing page curl is a Compose-based 3D approximation and not a copy of FoldChiyomi's renderer.
